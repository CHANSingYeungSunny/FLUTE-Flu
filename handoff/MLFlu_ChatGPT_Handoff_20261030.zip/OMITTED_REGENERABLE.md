# Omitted from this package (regenerable / redundant)

To keep the zip under GitHub's 100 MB per-file limit, the following were intentionally left out.
Nothing here affects any conclusion; all are regenerable or redundant copies.

| Omitted | Size | How to get it / why it is safe |
|---------|-----:|--------------------------------|
| `results/.../peak_criteria/s1es_runs/` (Track-S early-stop checkpoints, `*.pth`) | ~217 MB | Regenerable by re-running the Track-S script; conclusion already summarised in `04_benchmark/TRACK_S_FINAL_REPORT_DECISION.md` + `S1ES_RESULTS_PER_FIT.csv` |
| `s1es_runs.tgz`, `miflu_test_csv.tgz` | ~124 MB | Tarballs of the above / of CSVs that are already included unpacked |
| Non-GPT2 text-embedding dumps (`LLAMA*`, `BERT*`, other date-stamped variants in author `text_emb/`) | ~277 MB | Regenerable via author `text_emb.ipynb`; the embeddings actually loaded by the released training code (`text_emb_label_0507_{24,36,48,60}.txt`) ARE included |
| `*.npz`, `*.pyc`, `__pycache__/` | — | caches / intermediate arrays |
| Historical experiment trees (`results/v2_legacy_archive/`, `v3_superseded_archive/`, `hpc_results/stage5_a2|stage6|hpc_a1*`) | large | superseded evidence, kept in the main repo only |
