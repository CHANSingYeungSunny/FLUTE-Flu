# ⚠ Data vintages — read before using

| File | Rows | sha256 (first 16) | What it is |
|------|-----:|-------------------|------------|
| `raw/national_illness_raw_paper_exact.csv` | 966 | 31ffc1693de205ca… | project-schema copy of the AUTHOR data (value-identical) |
| `raw/national_illness_raw.csv` | 1025 | c2b983af2bf38614… | 2026-07 FluView snapshot — DIFFERENT vintage, values revised from MMWR 2016w40 |

**Never mix scores computed on these two files.** The official data is the author's 966-row
`national_illness.csv` (see `02_author_repo/code/dataset/illness/`, sha256 2a96dfed…ebfe5).
The author CSV's `date` column is a synthetic 7-day index, not real CDC weeks.
