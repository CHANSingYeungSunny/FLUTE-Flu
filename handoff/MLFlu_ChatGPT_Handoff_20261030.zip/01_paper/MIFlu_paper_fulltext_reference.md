# MIFlu: Large Language Model-Based Multimodal Influenza Forecasting Scheme

**Jaeuk Moon** (*Member, IEEE*), **Jonghwa Shim**, **Eunbeen Kim**, and **Eenjun Hwang** (*Member, IEEE*)

*IEEE Journal of Biomedical and Health Informatics, Vol. 29, No. 10, October 2025, pp. 7790–7801*
DOI: 10.1109/JBHI.2025.3561214

> Received 18 November 2024; revised 21 March 2025 and 27 March 2025; accepted 12 April 2025. Date of publication 15 April 2025; date of current version 7 October 2025. This work was supported by NRF (National Research Foundation of Korea) under Grant RS-2023-00252257 and in part by the NRF Korean Government (MSIT) under Grant RS-2024-00397293. (Corresponding author: Eenjun Hwang.)
>
> The authors are with the School of Electrical Engineering, Korea University, Seoul 02841, South Korea (e-mail: jaewookmo@korea.ac.kr; indexlibrorum3822@korea.ac.kr; gichanac@korea.ac.kr; ehwang04@korea.ac.kr).

---

## Abstract

In order to minimize the impact of influenza on public health, accurate early forecasting is essential. Various deep-learning-based models have been proposed to predict future influenza occurrences by capturing temporal/regional patterns from past occurrence time-series data. However, the prediction performance of these unimodal approaches is limited because they extract knowledge only from collected data, and users cannot input contextual information and domain knowledge to them. Recently, large language models (LLMs) have demonstrated the potential to improve prediction accuracy by linking contextual text information to time-series predictions. In this paper, we propose MIFlu, a multimodal influenza forecasting scheme that can fuse contextual text information to time-series influenza occurrences using two LLMs. It first extracts text embeddings from the user's text prompts that contain contextual information using a text-embedding LLM. Then, MIFlu fuses the text embeddings and time-series embeddings and uses the fused embeddings to predict future occurrences using a forecasting LLM. In extensive experiments using public national/regional influenza datasets, MIFlu outperforms other predictive models, improving prediction performance by up to 26.2% compared to state-of-the-art models. We also analyze the effect of various textual input embedders, hyperparameters, and the amount of training data on forecasting accuracy.

**Index Terms** — Artificial neural network, deep learning, ILI prediction, large language models, multimodal forecasting.

---

## I. Introduction

Infectious diseases transmitted through the respiratory tract have severe economic, social, and health impacts on society. The recent coronavirus disease (COVID-19) outbreak has clearly demonstrated the widespread negative consequences of infectious diseases, such as massive mortality and global economic disruption. Influenza is also a major public health challenge, with the World Health Organization (WHO) estimating that influenza causes 3 to 5 million severe symptomatic illnesses and 290,000 to 650,000 deaths every year [1]. Early forecasting of influenza outbreaks can reduce the severity of impacts by allowing time for countermeasures such as vaccine manufacturing, implementation of prevention policies, and introduction of quarantine protocols before an outbreak occurs [2].

To date, influenza forecasting has typically relied on multivariate time-series forecasting approaches that predict future influenza occurrences in multiple regions/variables using only past occurrence data for those regions/variables. Here, exogenous data such as internet search or weather data are not utilized because of their limited availability and reliability [3], [4], [5]. To this end, researchers have attempted to capture temporal patterns and interrelationships in influenza occurrence data across different regions/variables (i.e., regional patterns) using deep-learning-based models [3], [4], [5]. For example, graph neural networks (GNNs), which consider each region/variable as a graph node and represent regional patterns as an adjacency matrix, have been used for influenza forecasting [3], [4]. More recently, self-attention mechanisms, which assign higher weights to relatively important components in the input data, have replaced GNNs for the modeling of regional patterns [5].

Domain knowledge such as disease characteristics, health policy changes, and task instructions (e.g., user prediction instructions) can be effectively used for influenza forecasting. Nevertheless, conventional forecasting methods are very limited in leveraging this contextual information because they are based on unimodal models that capture time-series temporal/regional patterns in historical influenza occurrences. To address this problem, an effective way to fuse data from different modalities, such as contextual text information and historical time-series data, is needed. One option for this is large language models (LLM), which have been extensively studied in various fields such as natural language processing [6], computer vision [7], and time-series tasks [8], [9]. In particular, autoregressive LLM models (e.g., GPT and LLaMA) based on transformer decoders can be used for predictions by pre-training the LLM via causal language modeling to predict masked words that appear after the input text, thus making them suitable for time-series forecasting [8], [9]. Pre-trained LLMs can also adapt to new tasks with only a few data points based on their pre-trained background knowledge and have the ability to encode the meaning/sequential patterns of text as latent vectors. Therefore, contextual information can be expressed as text and incorporated into time-series forecasting.

Based on this observation, in this paper, we propose MIFlu, a multimodal influenza forecasting scheme that can produce more accurate predictions by fusing contextual information expressed in text format with time-series influenza occurrence data using two LLMs. MIFlu consists of three components:

1. a textual input embedder that outputs text embeddings using tokenizer and text-embedding LLM for text prompts containing forecasting instructions, statistical knowledge of data, dataset description, and domain knowledge from experts;
2. a time-series input embedder that normalizes time-series influenza occurrence data, divides it into patches, and outputs time-series input embeddings; and
3. a forecasting LLM that predicts future influenza occurrences based on the fusion of the two embeddings by fine-tuning only a few LLM parameters and additional parameters using a parameter-efficient fine-tuning (PEFT) technique.

We compared the forecasting accuracy of MIFlu with comparative models using national/regional influenza forecasting tasks. We also analyze its forecasting performance when changes are made to the textual input embedder, hyperparameters, text prompt, and amount of training data. Finally, we investigate through an ablation study whether each component of MIFlu is essential.

The main contributions of this study are as follows:

- We propose a multimodal influenza forecasting model that fuses textual domain knowledge and time-series occurrence data using two LLMs. To the best of our knowledge, this is the first study to employ multimodal forecasting based on LLM for influenza forecasting.
- We demonstrate through various experiments that the proposed model outperforms other state-of-the-art (SOTA) models in national/regional influenza forecasting tasks.
- We present a prompt template that provides contextual information to the forecasting LLM to enrich its interpretation of time-series influenza occurrences.

The remainder of this paper is organized as follows. Section II presents related work, while Section III provides preliminaries. Section IV then describes the proposed model, Section V describes the experimental settings, and Section VI summarizes the results. Finally, Section VII concludes the paper and discusses limitations and future work.

---

## II. Related Work

Regional influenza forecasting predicts future influenza occurrences in multiple regions using only historical occurrence data from those regions. Here, exogenous data such as internet search (e.g., Google Trend) or weather data are not utilized because of their limited availability and reliability [3], [4], [5]. Due to the nature of infectious diseases, which spread rapidly across regions over time, researchers have focused on jointly capturing temporal and regional patterns of influenza outbreaks [10]. To achieve this, deep-learning models such as recurrent neural networks (RNNs) and GNNs have been widely used. RNNs and their variants, such as long short-term memory (LSTM) and gated recurrent units, are specialized for capturing temporal patterns. For example, Wu et al. [4] utilized an RNN to learn temporal patterns in specific regions and adopted a convolutional neural network (CNN) to fuse temporal patterns in multiple regions to capture regional patterns. They also added residual connections between time sequences to avoid overfitting during the training process. In contrast, GNNs consider each region as a graph node and can effectively represent regional patterns with an adjacency matrix. For example, Deng et al. [3] first captured the temporal patterns of nodes using a temporal CNN and utilized these patterns in a node feature matrix. Subsequently, they used an RNN to extract features from each node and utilized these features to construct an adjacency matrix that represents regional patterns. The node feature matrix and adjacency matrix were incorporated using a GNN to predict future influenza occurrences.

Self-attention mechanisms can also be used to capture regional patterns by assigning higher weights to relatively important components in the input data. For example, Jung et al. [5], [10] proposed the influenza forecasting model SAIFlu-Net using this mechanism. They first used LSTM to obtain the temporal patterns of each region and used these patterns as a query and key for each region. The self-attention mechanism then calculated regional patterns for regional influenza forecasting. They demonstrated that SAIFlu-Net was superior to previous regional influenza forecasting models, including CNNRNN and Cola-GNN.

Transformers, first introduced by Vaswani et al. [11], have recently been used for multivariate time-series forecasting. The transformer architecture consists of two modules that rely heavily on self-attention: an encoder that understands the input data and a decoder that generates an output sequence based on knowledge from the encoder. The transformer [11] is suitable for capturing long-term temporal patterns due to its self-attention, which can capture temporal patterns over the entire period of the input data. Therefore, researchers have used transformers and their variants for long-term forecasting, including national influenza forecasting which predicts multiple different variables that represent the influenza occurrence of one country. Kitaev et al. [12] proposed the long-term forecasting model Reformer, which was based on a transformer. They utilized locality-sensitive hashing to perform an approximate nearest neighbor search, which led to a more memory-efficient transformer. Wu et al. [13] also modified a transformer to develop a decomposition forecasting architecture. They decomposed the input time series into patches divided by the time axis and replaced self-attention with an auto-correlation module. This allowed the model to capture seasonal and cyclic temporal patterns.

Recently, LLMs based on transformer architectures pretrained on large-scale text databases have demonstrated remarkable performance in a variety of natural language processing (NLP) tasks, attempts have been made to utilize LLMs for time-series forecasting by aligning time-series features with text features. For example, Zhou et al. [9] proved that fine-tuning only the first several layers of the pre-trained GPT2 with an added output layer appropriate for the downstream task can outperform existing transformer-based models in various time-series tasks such as long- and short-term forecasting, classification, and anomaly detection.

These previous approaches are unimodal influenza forecasting models that are trained solely to predict future values by capturing complicated temporal and regional patterns from historical time-series data. They cannot leverage expert domain knowledge or external information, which is mainly expressed in text. Fusing multiple types of knowledge from different modalities is very useful for improving the accuracy of epidemics prediction. For example, Papagiannopoulou et al. [14] attempted to incorporate a diverse range of exogenous data (e.g., meteorological and population data) based on self-attention in order to capture the variation in influenza occurrences. Despite the SOTA regional influenza forecasting accuracy, their approach represented the exogenous information as time-series data. In addition, for countries where exogenous data are not available, the forecasting model cannot be used because the input dimensions of the trained model differ for that country. This can be addressed by enriching the influenza occurrence information by adding textual prompts to the time-series data and using an LLM pre-trained on these multimodal data.

---

## III. Preliminaries

In this section, we formulate national and regional influenza-like illness forecasting tasks and briefly review LLMs for ILI forecasting.

### A. Problem Formulation

We formulate influenza forecasting as a multivariate time-series forecasting task that predicts the number of future ILI patients. Hereafter, we define "ILI" as the ILI patient count in both national and regional ILI forecasting. Here, *N* represents the number of variables, *L* represents the number of future weeks to predict, and *T* represents the time length of the input data. $x_i^t \in \mathbb{R}$ denotes the ILI for the *i*-th variable at time *t* and $X_i = [x_i^1, \ldots, x_i^T] \in \mathbb{R}^T$ is the set of ILIs in region *i* over the past *T* weeks. The undefined notations in this section are described in detail later. Below is a description of two influenza forecasting tasks that differ in the configuration of variables:

**1) National ILI Forecasting:** National ILI forecasting predicts not only the ILI for the entire country (i.e., national ILI), but also several variables that represent sub-indicators of national ILI. The variables can contain national ILI, ILI for specific age groups, and ILI adjusted for population size or the number of reporting providers (see Table II). Following [9], the goal of national ILI forecasting is to predict the ILI for *L* continuous future weeks based on *N* variables for a window size of the past *T* weeks, where $X_{input} \in \mathbb{R}^{N \times T}$ is the input for forecasting model *f* (1):

$$
\hat{Y} = [\hat{Y}^{t+L}, \ldots, \hat{Y}^{t+1}] = f(X_{input}) = f\left(X^{t-(T-1)}, \ldots, X^{t-1}, X^{t}\right) = f\begin{pmatrix} x_1^{t-(T-1)} & \cdots & x_1^{t} \\ \vdots & \ddots & \vdots \\ x_N^{t-(T-1)} & \cdots & x_N^{t} \end{pmatrix} \tag{1}
$$

**2) Regional ILI Forecasting:** Unlike the national ILI forecasting, the variables for this task consist of only ILI of *N* regions. Following several studies [3], [4], [5], [14], the goal of regional ILI forecasting has been to forecast the ILI after *L* weeks in *N* regions by using $X_{input}$ as an input for *f*, as described in (2).

$$
\hat{y}^{t+L} = f(X_{input}) \tag{2}
$$

### B. LLM

Most LLMs are based on a transformer that relies on a self-attention mechanism. In general, the transformer structure consists of an encoder and a decoder, leading to two main types of LLM: autoencoding models based on an encoder (e.g., BERT [15]) and autoregressive models based on an decoder (e.g., GPT [16] and a LLaMA [17]). Autoencoding models are widely used in downstream tasks in which understanding the input text is important, such as word/document classification or sentiment analysis, while autoregressive models aim to generate text that is likely to follow the input text. Autoregressive models are trained on large volumes of unlabeled text data using self-supervised learning, in which they learn to predict the next masked word as the label of the input text. This predictive ability generated during the training process in causal language modeling makes LLMs suitable for time-series forecasting tasks [18].

### C. Parameter Efficient Fine-Tuning

As LLMs are pre-trained with diverse and large amounts of data, fine-tuning is essential to utilize LLM for a specific task. However, fine-tuning all the layers of LLMs on small, domain-specific dataset can make LLM forget most of the pre-trained knowledge during the fine-tuning process [22]. This problem is called catastrophic forgetting, which raises the importance of new training methods.

PEFT [23] has emerged as an effective solution to this problem by selectively optimizing essential parameters while leaving the other parameters unchanged. Of the PEFT techniques that have been developed, we use low-rank adaptation (LoRA) [24] due to its adaptation performance. LoRA adds lightweight, fully connected layers in parallel to specific layers of the pre-trained LLM and updates only these added layers.

---

## IV. Proposed Scheme

As shown in Fig. 1, the overall structure of the proposed scheme consists of three modules: a textual input embedder, a time-series input embedder, and a forecasting LLM.

**Fig. 1. Architecture of the proposed scheme.**

*(Figure description: Textual input → Tokenizer → Text-embedding LLM (frozen) → textual input embeddings $h_{text}$. Time-series input → Instance norm + Patching → Linear embedder (trainable) → time-series input embeddings $h_{time}$. The two embeddings are concatenated (length: len(token) + num(patches)) and fed to the Forecasting LLM, which outputs forecasting embeddings $h_{forecast}$; the last num(patches) positions pass through a trainable Output projection. Right panel: each of the K transformer blocks of the forecasting LLM contains Multi-Head Attention (with frozen $W_q$, $W_k$, $W_v$ and trainable parallel LoRA adapters on Q and K paths; hidden states + trainable positional encoding PE), Add & Norm (trainable), Feed Forward (frozen), Add & Norm (trainable). The textual input prompt format is: [Dataset description]: <Dataset information>; [Input variable description]: <Statistics and user's knowledge of time-series 1–N>; [Instruction]: <Task information>.)*

### A. Textual Input Embedder

The textual input embedder constructs a text prompt containing contextual information such as domain knowledge and task instructions and encodes the prompt into the text embeddings so that MIFlu can forecast future ILIs based on the richer information compared to the unimodal ILI forecasting. For example, MIFlu can take into account insights from infectious disease experts about future ILI patterns or changes in public health policy in its infectious disease forecasting. Also, text prompts provide real-time updates that enable forecasting models to quickly adapt to rapid changes of ILI patterns (e.g., emergence of new strains, public health interventions, or changes in public behavior) [8].

We construct a text prompt template for influenza forecasting that includes the dataset information, task instructions, and description of the input variables, following the template of [18]. A template of the input text prompt is presented in Table I (full example is presented in Appendix). The dataset information provides the essential background information for the dataset, such as the number of variables, the dataset domain, and the period of $X_i^{train}$ (i.e., training input data of region *i*) for the LLM. The description of the input variables used during the training period includes statistics (e.g., the minimum and maximum for $X_i^{train}$) and domain knowledge from the user. We use the overall trend for $X_i^{train}$ and the number of peak timings each year. Finally, the task instructions include details of the forecasting task, including lead time *L* and window size *T*.

**TABLE I — Template of an Input Text Prompt**

```
[Dataset information]
<Description of dataset>
Below (1) to (N) is the information about each feature:
***
[Input variable description]
(1) <Description of variable 1> + <Statistics: Max, Min> + <Domain knowledge from experts/users of variable 1>
...
(i) <Description of variable i> + <Statistics: Max, Min> + <Domain knowledge from experts/users of variable i>
...
(N) <Description of variable N> + <Statistics: Max, Min> + <Domain knowledge from experts/users of variable N>
***
[Task instruction]
Predict the next <L> steps given the previous <T> steps for the information attached.
```

Textual input embedder consists of a tokenizer and text-embedding LLM. After constructing the input text prompt, we use the text-embedding LLM to obtain embedding vectors for the input prompt. To achieve this, we first tokenize the text using a pre-trained tokenizer. Each token is then mapped to a unique numerical identifier (ID) using a pre-defined dictionary. This dictionary is built during the pre-training of the LLM. Finally, the LLM transforms each token into embedding vector *D*. The output of this module is the hidden states of the textual inputs $h_{text} \in \mathbb{R}^{(len(token)) \times D}$, where len(token) and $D \in \mathbb{R}^d$ represent the total token length of the text converted to tokens and the dimensions of the input and output of the LLM, respectively.

### B. Time-Series Input Embedder

LLMs are usually pre-trained using text data, thus time-series ILI data need to be converted for use as input to the forecasting LLM to predict future ILIs. For this purpose, we use an input embedder consisting of three layers: instance normalization, patching, and linear embedder. The ILI distribution of a region or country varies over time, but excessive variation in the data distribution can lead to overfitting and unstable training. Therefore, to mitigate changes in the distribution over time, we impose reversible instance normalization [19] on each variable in $X_{input}$ by subtracting the mean $X_{input}$ from $X_{input}$ and dividing the result by the standard deviation of $X_{input}$.

In general, ILI data exhibits temporal patterns over various periods (e.g., weeks or months) and has a repetitive temporal pattern for the peak values in specific seasons every year. Therefore, we convert the normalized $X_{input}$ into patch-based tokens with patching $X_{input}$ that incorporates adjacent time steps. This process can better preserve short-term patterns and reduce the computational load of an LLM. The length of each patch is $L_p$ and the total number of input patches is $\lfloor (T - L_p)/S \rfloor + 2$, where *S* represents the horizontal sliding stride. The output for instance normalization and the patching layer is $h_t \in \mathbb{R}^{num(patches) \times P}$, where num(patches) is the number of total patches converted from $X_{input}$ and *P* is the patch size. Finally, we employ linear embedder to project processed time-series data $h_t$ onto the dimensions [num(patches), *D*] required for input into the forecasting LLM. The linear embedder is trainable so that the forecasting LLM can appropriately utilize the time-series input. The output of this module is $h_{time} \in \mathbb{R}^{num(patches) \times D}$.

### C. Forecasting LLM

The forecasting LLM module concatenates $h_{time}$ and $h_{text}$ obtained from the time-series input embedder and textual input embedder, respectively, to create $h_{fuse} \in \mathbb{R}^{(len(token)+num(patches)) \times D}$ and predict future ILIs. We use an autoregressive LLM for forecasting model for several reasons. First, the autoregressive LLM employs causal language modeling that allows masked words that follow the input text to be learned during training [18]. Second, the LLM contains multiple decoders from the transformer, which have demonstrated outstanding performance in processing long-term temporal patterns [11]. The reason for conducting long-term forecasting is time-consuming nature of vaccine transportation/distribution, vaccination, policy decision, and budget allocation. Finally, the LLM can adapt to new tasks with small volumes of data via its pre-trained knowledge. This is important for ILI forecasting, where data are collected on a weekly basis rather than on a minute or second basis [20]. In other words, weekly patient counts would provide only about 520 data points after 10 years of data collection, which can lead to data shortage problems.

The main components of the autoregressive LLM are the positional encoding layer (PE) and transformer blocks, which consist of multi-head attention, layer normalization, and feed-forward layers. Of these layers, we only fine-tune the positional encoding and layer normalization layers following a standard training technique [9], [21]. However, unlike previous studies that conducted various time-series tasks using an LLM with unimodal data [9], MIFlu forecasts future ILIs with $h_{fuse}$, a fused embedding of text and time-series information. Therefore, the multi-head attention layer also needs to be fine-tuned to capture new relationships within the fused embedding. This leads to a significant issue: because the multi-head attention and feed-forward layers contain most of the pre-trained knowledge, fine-tuning these layers with small-scale ILI data can lead to the catastrophic forgetting problem in which most of the pre-trained knowledge is forgotten during the fine-tuning process [22]. To address this problem, we employ LoRA only to the multi-head attention layer; therefore, the pre-trained LLM is allowed to learn new relationships in $h_{fuse}$ without compromising its inference speed.

After the transformer blocks, we obtain the forecasting embeddings $h_{forecast} \in \mathbb{R}^{(num(patches)+len(token)) \times D}$ (which has the same dimensions as $h_{fuse}$) autoregressively. In other words, when the forecasting LLM takes the *i*-th token $h_{fuse}[i]$ as input, the forecasting result for the $h_{fuse}[i]$ is $h_{forecast}[i]$, which means that the order of the input and output tokens is the same. Because our goal is to predict future ILIs after the input of historical ILIs, we discard the token part $h_{forecast}[len(token){:}] \in \mathbb{R}^{(len(token)) \times D}$ from $h_{forecast}$ to make $h'_{forecast} \in \mathbb{R}^{(num(patches)) \times D}$. Afterward, we project $h'_{forecast}$ to the final forecasting result $\hat{y}^{t+L}$ (for regional ILI forecasting) or $\hat{y}^{t+L}, \ldots, \hat{y}^{t+1}$ (for national ILI forecasting) using the output projection, which is a linear embedder layer.

---

## V. Experimental Settings

Before describing the experiments to evaluate the effectiveness of MIFlu, we first present the datasets, the evaluation metrics, and the experimental settings we used in the experiments.

### A. Datasets

The two datasets used in the experiments are:

- **National-Illness [25]:** This dataset includes seven variables for national ILIs that occurred in the United States (US) between 2002 and 2021, including ILI occurrence for ages 0 to 4 years, number of outpatient providers, and total national ILI. This dataset has been widely used to compare the accuracy of long-term ILI forecasting (i.e., lead times *L* longer than 24 weeks) of transformer-based models. Following previous studies [9], [21], we split the data into training, validation, and test set at a ratio of 70:10:20.
- **US-Region [25]:** The Department of Health and Human Services (HHS) divides the US into 10 regions by grouping related states within each region. This dataset contains ILI in those 10 HHS regions from week 40, 1997, to week 18, 2020. Following [14] and our previous work [5], we divide the data into training, validation, and test set at a ratio of 50:10:40.

Tables II and III present the descriptive statistics of each variable and region for the National-Illness and US-Region datasets, respectively. For the US-Region datasets, we also show statistics for the whole dataset. Fig. 2(a) and (b) show boxen plots for each variable and region used in the national and regional ILI datasets, respectively.

**TABLE II — Descriptive Statistics of the National-Illness Dataset**

| Variable ID | Description | Average | Max | SD |
|:-----------:|-------------|--------:|----:|---:|
| 1 | Percentage of ILI patient visits to healthcare center (weighted by regional population) | 1.851 | 7.715 | 1.342 |
| 2 | Percentage of ILI patient visits to healthcare center (unweighted by regional population) | 1.845 | 7.780 | 1.308 |
| 3 | ILI patient count of age 0-4 | 3434.814 | 24097 | 3152.330 |
| 4 | ILI patient count of age 5-24 | 4981.128 | 45513 | 5950.799 |
| 5 | Total ILI patient count | 13540.720 | 111361 | 15003.120 |
| 6 | Number of healthcare providers providing ILI patient count | 1608.262 | 3453 | 681.227 |
| 7 | Total number of ILI patient visits to healthcare center | 651497.500 | 1640587 | 348838.200 |

**TABLE III — Descriptive Statistics of the US-Region Dataset**

| Region ID | Average | Max | SD |
|:---------:|--------:|----:|---:|
| 1 | 444.586 | 10890 | 885.980 |
| 2 | 1661.472 | 16433 | 2314.758 |
| 3 | 1574.766 | 18694 | 2526.018 |
| 4 | 2286.980 | 30282 | 3515.544 |
| 5 | 1178.448 | 11269 | 1385.680 |
| 6 | 1566.005 | 13616 | 2193.085 |
| 7 | 267.390 | 4409 | 435.360 |
| 8 | 541.713 | 7275 | 869.223 |
| 9 | 991.453 | 5882 | 911.894 |
| 10 | 215.022 | 5115 | 486.705 |
| **Total** | 1,072.780 | 30,282 | 1,949.170 |

**Fig. 2. Boxen plots for the variables and regions used in the national-Illness and US-region datasets, respectively.**

*(a) Boxen plot for the National-Illness dataset — Variables 1–7 (x-axes: percentage of ILI patient for Variables 1–2; ILI patient count for Variables 3–5 and 7; number of healthcare providers for Variable 6).*
*(b) Boxen plot for the US-Region dataset — Regions 1–10 (x-axis: ILI patient count, 0–30000).*

### B. Evaluation Metrics

We compare the national and regional ILI forecasting accuracy using two widely used metrics for each task. For national ILI forecasting, all models have been compared through mean square error (MSE) and mean absolute error (MAE) [9], [26], [27], [28], [29], [30], [31], [32]. As can be seen from the Equations, MSE is sensitive to large errors, so it is suitable for comparing the peak intensity prediction performance of ILI. On the other hand, MAE uses the overall mean error to evaluate the general prediction performance of the model. We first normalize each input variable to a normal distribution using StandardScaler. The mean square error (MSE) and mean absolute error (MAE) are then calculated using (3) and (4). These metrics reflect the mean difference between actual ILI $Y_i$ and predicted ILI $\hat{Y}_i$ for *M* data points.

For regional ILI forecasting, the root mean square error (RMSE) and Pearson correlation coefficients (PCCs) have been widely used [3], [4], [5], [10], [14]. RMSE is more sensitive to large errors than MAE because it uses the square root of the mean squared error. PCC is useful for evaluating whether the forecasting model effectively captures the trend of ILI. Unlike national ILI forecasting, these metrics have been used after de-normalizing the values to reproduce the original range. The RMSE is calculated using (5), which measures the difference between $Y_i$ and $\hat{Y}_i$. The PCC is calculated using (6), where $\overline{Y_i}$ and $\overline{\hat{Y}}$ are the mean values of the actual and predicted ILIs, respectively.

$$
\text{MSE} = \frac{1}{M}\sum_{n=1}^{M}\left(Y_n - \hat{Y}_n\right)^2 \tag{3}
$$

$$
\text{MAE} = \frac{1}{M}\sum_{n=1}^{M}\left|Y_n - \hat{Y}_n\right| \tag{4}
$$

$$
\text{RMSE} = \sqrt{\frac{1}{M}\sum_{n=1}^{M}\left(Y_n - \hat{Y}_n\right)^2} \tag{5}
$$

$$
\text{PCC} = \frac{\sum_{n=1}^{M}\left(\hat{Y}_n - \overline{\hat{Y}_n}\right)\left(Y_n - \overline{Y_n}\right)}{\sqrt{\sum_{n=1}^{M}\left(\hat{Y}_n - \overline{\hat{Y}_n}\right)^2}\sqrt{\sum_{n=1}^{M}\left(Y_n - \overline{Y_n}\right)^2}} \tag{6}
$$

### C. Experimental Details

To compare the forecasting performance of our proposed model, we consider SOTA models proposed for ILI forecasting. Table IV presents the list of models we compare for national/regional ILI forecasting and their hyperparameters. These settings are the same as those reported in previous studies [9], [14]. The results for the national and regional ILI forecasting models are taken from [9] and [14], respectively.

**TABLE IV — A List of Comparative Models and Hyperparameters Used**

| Settings | Model Classification | National ILI forecasting | Regional ILI forecasting |
|----------|----------------------|--------------------------|--------------------------|
| Comparative models | Unimodal LLM | GPT4TS [9] | GPT4TS [9] |
| Comparative models | Transformer | ETSformer [27], LightTS [28], FEDformer [30], PatchTST [31], Stationary [32], Autoformer [13], Informer [33], Reformer [12] | TFT [34] |
| Comparative models | Attention | - | ReILIF [14], SAIFlu-Net [5] |
| Comparative models | GNN | - | Cola-GNN [3], CNNRNN [4], STNN [35] |
| Comparative models | Others | TimesNet [26], DLinear [29] | - |
| L | | 24, 36, 48, 60 | 2, 3, 5, 10, 13, 15, 20 |
| Epochs | | 20 | 50 |
| Batch size | | 16 | 32 |
| Learning rate | | 0.0005 | 0.0005 |
| T | | 104 | 20 |

In these papers, national ILI has been conducted for long-term forecasting ($L \geq 24$), while regional ILI has been conducted for rather short-term forecasting ($L \leq 24$). This is because, due to the rapid and irregular nature of influenza spread at the regional level, regional data are inherently volatile, making short-term forecasts more practical for immediate public health response. In contrast, national forecasts based on aggregated data from multiple regions suppress regional fluctuations and focus on long-term, persistent seasonal patterns or trends.

Three versions of the ReILIF model used for regional ILI forecasting have been developed: ReILIF$_{NoC}$, which uses only ILI; ReILIF$_{TV}$, which uses ILI and time-varying exogenous data (e.g., wind and temperature data); and ReILIF$_{TV/S}$, which uses static exogenous data (e.g., population and population density). We present the results for ReILIF$_{TV/S}$ as the representative of ReILIF because MIFlu uses textual information that is static over time [14].

We set the number of training epochs and the learning rate for MIFlu empirically because the hyperparameters vary depending on the base model. For our forecasting LLM, we use the first *K* layers of the original GPT2 according to [9]. Here, *K* is set at 6 for national ILI forecasting following [9], while *K* is set at 4 for regional ILI forecasting based on the results presented in Section VI-D. In these layers, we set low-rank dimension *r* to 4 following [36]. In addition, for national ILI forecasting, we set $L_p$ and *S* to 24 and 2, respectively, according to [9], and for regional ILI forecasting, we set them to 4 and 2 based on the ratio of *T* and $L_p$ and *S* in national ILI prediction. For the textual input embedder, we use full GPT2 to align the pre-trained knowledge with the forecasting LLM (see Section VI-C for more details). Here, SOTA LLMs like GPT4o cannot be considered because we cannot modify the structure of those models, and they must be trained using only text data with a fixed template.

We assess the forecasting performance by calculating the mean of 10 repetitions of the forecasting results. We implement the proposed model using Python 3.9.18 with PyTorch 2.1.0 and a GeForce RTX 3090.

---

## VI. Experimental Results

To demonstrate the effectiveness of MIFlu, we conduct experiments using public national and regional ILI datasets. We first compare the forecasting accuracy of MIFlu with SOTA ILI forecasting models for national and regional ILI forecasting. We then investigate the effect of textual input embedders and changes in hyperparameters on forecasting performance. Finally, we analyze the effectiveness of each MIFlu component through ablation study and evaluate the few-shot forecasting performance.

### A. National ILI Forecasting

In this experiment, we compare the forecasting performance of MIFlu with that of previously reported models using the national ILI dataset. Table V presents the forecasting accuracy in terms of the MSE and MAE. The bold and underlined values indicate the most and second-most accurate predictions, respectively. MIFlu outperforms the other models in all cases except for the MSE at *L* = 24. Because national ILI forecasting generally involves long-term predictions, most of the previous models are based on a transformer architecture that can effectively capture long-term temporal patterns. However, recent models such as TimesNet and DLinear do not rely on transformers to capture long-term temporal patterns in ILI, but they still produce an outstanding performance. Except for PatchTST, GPT4TS outperforms all of the other compared models due to its pre-trained knowledge of a large volume of textual data. However, PatchTST maximizes the performance of the transformer and achieves the second-best performance based on the average MSE/MAE for ILI predictions. MIFlu performs well because it incorporates the user's prior knowledge via the textual input embedder and LoRA fine-tuning to improve the forecasting performance of GPT2. Fig. 3 shows that MIFlu outperforms all comparative models in terms of the average forecasting performance of all *L*.

**TABLE V — MSE and MAE of the Comparative Models for National ILI Forecasting**

*(Bold = most accurate; <u>underlined</u> = second most accurate)*

| L | Metric | MIFlu | GPT4TS | DLinear | PatchTST | TimesNet | FEDformer | Autoformer | Stationary | ETSformer | LightTS | Informer | Reformer |
|---|--------|-------|--------|---------|----------|----------|-----------|------------|------------|-----------|---------|----------|----------|
| 24 | MSE | <u>1.542</u> | 2.063 | 2.215 | **1.319** | 2.317 | 3.228 | 3.483 | 2.294 | 2.527 | 8.313 | 5.764 | 4.400 |
| 24 | MAE | **0.726** | 0.881 | 1.081 | <u>0.754</u> | 0.934 | 1.260 | 1.287 | 0.945 | 1.020 | 2.144 | 1.677 | 1.382 |
| 36 | MSE | **1.422** | 1.868 | 1.963 | <u>1.430</u> | 1.972 | 2.679 | 3.103 | 1.825 | 2.615 | 6.631 | 4.755 | 4.783 |
| 36 | MAE | **0.779** | 0.892 | 0.963 | <u>0.834</u> | 0.920 | 1.080 | 1.148 | 0.848 | 1.007 | 1.902 | 1.467 | 1.448 |
| 48 | MSE | **1.414** | 1.790 | 2.130 | <u>1.553</u> | 2.238 | 2.622 | 2.669 | 2.010 | 2.359 | 7.299 | 4.763 | 4.832 |
| 48 | MAE | **0.757** | 0.884 | 1.024 | <u>0.815</u> | 0.940 | 1.078 | 1.085 | 0.900 | 0.972 | 1.982 | 1.469 | 1.465 |
| 60 | MSE | **1.364** | 1.979 | 2.368 | <u>1.470</u> | 2.027 | 2.857 | 2.770 | 2.178 | 2.487 | 7.283 | 5.264 | 4.882 |
| 60 | MAE | **0.719** | 0.957 | 1.096 | <u>0.788</u> | 0.928 | 1.157 | 1.125 | 0.963 | 1.016 | 1.985 | 1.564 | 1.483 |

**Fig. 3. Comparison of average forecasting performance for L = 24, 36, 48, 60.**

*(Figure description: grouped bar chart of average MSE and MAE for MIFlu, GPT4TS, DLinear, PatchTST, TimesNet, FEDformer, Autoformer, Stationary, ETSformer, LightTS, Informer, and Reformer. MIFlu has the lowest bars in both MSE and MAE; LightTS has the highest MSE (~7+).)*

### B. Regional ILI Forecasting

We also compare the forecasting accuracy of each model and lead time *L* for regional ILI forecasting using the US-Region dataset. Table VI presents the forecasting performance in terms of the RMSE and PCC. The bold and underlined values indicate the most and second-most accurate results, respectively. Following [5], [14], prediction results with a lead time *L* longer than 5 are considered long-term and those less than or equal to 5 are considered short-term in regional ILI forecasting. Because influenza monitoring data are delayed by at least one week, forecasting results for *L* = 1 are not considered.

**TABLE VI — RMSE/PCC of the Comparative Models for Regional ILI Forecasting**

*(Bold = most accurate; <u>underlined</u> = second most accurate; format: RMSE / PCC)*

| L | MIFlu | GPT4TS | ReILIF | TFT | SAIFlu-Net | Cola-GNN | STNN | CNNRNN |
|---|-------|--------|--------|-----|------------|----------|------|--------|
| 2 | **771.9 / 0.937** | 998.1 / 0.915 | 1354.8 / 0.876 | 1247.2 / 0.867 | 1016.2 / 0.908 | <u>1006.1 / 0.920</u> | 1259.0 / 0.885 | 1130.4 / 0.902 |
| 3 | **963.4 / 0.883** | 1306.0 / <u>0.850</u> | 1555.2 / 0.819 | 1444.6 / 0.816 | <u>1306.0</u> / 0.847 | 1431.3 / 0.832 | 1576.5 / 0.820 | 1492.6 / 0.818 |
| 5 | **1331.49 / 0.779** | <u>1571.5</u> / 0.761 | 2293.7 / 0.707 | 1675.8 / 0.738 | 1681.8 / 0.728 | 1737.4 / <u>0.750</u> | 1934.5 / 0.677 | 1844.0 / 0.727 |
| 10 | **1893.4 / 0.719** | 1992.4 / 0.685 | <u>1955.4 / 0.701</u> | 2167.1 / 0.601 | 2050.0 / 0.608 | 2289.9 / 0.494 | 2404.6 / 0.255 | 2382.7 / 0.271 |
| 13 | **1943.8 / 0.701** | 2047.1 / 0.682 | <u>1996.4 / 0.685</u> | 2388.4 / 0.530 | 2140.0 / 0.599 | 2448.5 / 0.448 | 2339.1 / 0.259 | 2465.5 / 0.198 |
| 15 | **1923.8 / 0.678** | <u>2213.0 / 0.651</u> | 2512.9 / 0.538 | 2518.2 / 0.479 | 2330.7 / 0.531 | 2437.9 / 0.446 | 2356.9 / 0.318 | 2482.5 / 0.147 |
| 20 | **1920.8 / 0.689** | <u>2077.3 / 0.641</u> | 2431.7 / 0.596 | 2723.5 / 0.369 | 2225.9 / 0.578 | 2423.1 / 0.475 | 2428.5 / 0.421 | 2542.3 / 0.195 |

MIFlu demonstrates the best performance in all cases. SAIFlu-Net, Cola-GNN, and ReILIF also perform well due to the use of attention mechanisms that capture regional patterns. ReILIF performs better than GPT4TS in some cases because ReILIF uses exogenous time-series data, while GPT4TS only uses ILI data. However, GPT4TS outperforms ReILIF in long-term forecasting (*L* = 15, 20) due to the architecture of the LLM, which consists of multiple transformer decoders. However, MIFlu utilizes knowledge from experts in textual format with two LLMs to predict future ILI with multimodal data. Therefore, MIFlu improves on the forecasting accuracy of GPT4TS and achieves a relative performance gain compared to the SOTA model of up to 26.2%. Before we applied GPT4TS in regional ILI forecasting, SOTA model for regional ILI forecasting was ReILIF and we achieves a relative gain compared to ReILIF of up to 43.0%.

Fig. 4(a) and (b) present the actual and predicted ILIs for MIFlu during the test period for the US-Region dataset when *L* = 2 and 20, respectively. We measure the mean ILI of all regions after conducting multi-regional forecasting. The results show that MIFlu can predict unusual peak timing and peak intensity in short-term forecasting (*L* = 2), which is crucial for infectious disease experts looking to make informed decisions. MIFlu can also predict the actual ILI trends in long-term forecasting (*L* = 20).

**Fig. 4. Comparison of the real and predicted ILIs for MIFlu using the US-Region dataset.**

*(a) L = 2 — line plot of actual vs. predicted ILI occurrences (y-axis 0–12000) over ~400 time steps; predictions closely track actual data including peaks.*
*(b) L = 20 — same axes (y-axis 0–10000); predictions follow the overall trend but with larger deviations at peaks.*

### C. Textual Input Embedder Analysis

In this experiment, we investigate the effects of the textual input embedder on the forecasting performance of MIFlu. Candidates for the textual input embedder are BERT, LLaMA2-7B, and GPT2. Table VII presents the experimental results according to the textual input embedder on the National-Illness dataset. Here, X (did not use textual input embedder) and GPT2 denoting the results for unimodal time-series GPT4TS and MIFlu, respectively. The results show that all three textual input embedders improve the ILI forecasting performance compared to unimodal GPT2. LLaMA2-7B outperforms BERT, likely because LLaMA2-7B has 7 billion parameters compared to only 110 million for BERT, while LLaMA2-7B is pre-trained on about 600 times more dataset tokens. However, even though both LLaMA2-7B and GPT2 operate based on the decoder of the transformer, they have different pre-trained knowledge and structure. Therefore, GPT2, the forecasting LLM, may have difficulty understanding the text embedding results by LLaMA2-7B. Thus, if GPT2 is also used as the forecasting LLM, the semantic information embedded by GPT2 in the previous stage may improve overall forecasting performance.

**TABLE VII — Forecasting Accuracy (MSE/MAE) Comparison Depending on Textual Input Embedder**

| Textual input embedder | L = 24 | L = 36 | L = 48 | L = 60 |
|------------------------|--------|--------|--------|--------|
| GPT2 (MIFlu) | 1.542 / 0.726 | 1.422 / 0.779 | 1.414 / 0.757 | 1.364 / 0.719 |
| LLaMA2-7B | 1.553 / 0.783 | 1.447 / 0.774 | 1.433 / 0.761 | 1.486 / 0.792 |
| BERT | 1.602 / 0.797 | 1.564 / 0.774 | 1.572 / 0.803 | 1.525 / 0.783 |
| X (GPT4TS) | 2.063 / 0.881 | 1.868 / 0.892 | 1.790 / 0.884 | 1.979 / 0.957 |

### D. Sensitivity Analysis

We also analyze the effect of the hyperparameters on the forecasting accuracy of MIFlu. First, we test the effect of window size *T* of the input time series. Fig. 5(a) and (b) present the forecasting results when *T* varies between 10 and 50 for the US-Region dataset (*L* = 20) in terms of the RMSE and PCC, respectively. When the target forecasting time is too far into the future, it is difficult to achieve high prediction accuracy with a short input window size (e.g., *T* = 10). Up until *T* = 40, a larger input window size leads to higher forecasting performance, likely because the forecasting model can utilize more data during training. However, at *T* = 50, the excessive input data can lead to overfitting, which degrades forecasting accuracy.

**Fig. 5. Changes in forecasting accuracy according to T.**

*(a) RMSE vs. window size T (10–50): RMSE falls from ~2800 at T = 10 to ~1900 at T = 20, ~1550 at T = 30, a minimum of ~1430 at T = 40, then rises slightly at T = 50.*
*(b) PCC vs. window size T (10–50): PCC rises from ~0.1 at T = 10 to ~0.7 at T = 20, ~0.8 at T = 30, ~0.82 at T = 40, and ~0.82 at T = 50.*

We also investigate the effect of the number of layers taken from the original GPT2 backbone (*K*) on the forecasting performance of MIFlu. In general, in a pre-trained LLM, layers close to the input contain generalizable information that can be applied to other tasks, and layers close to the output contain task/data-specific information [37]. Therefore, when a pre-trained LLM is utilized for another task such as time-series predictions, it is important to select the appropriate number of layers from the input. The original small GPT2 model has 12 layers, and Fig. 6 presents the forecasting results when *K* varies between 1 and 7 for the US-Region dataset (*L* = 20). Until *K* = 4, a higher *K* improves the forecasting performance, possibly because smaller models have a lower amount of pre-trained information, which means the number of parameters that can be adapted to new tasks is lower. In contrast, when there are more than six layers, text-specific information is more likely to be incorporated, which can reduce forecasting accuracy. Nevertheless, regardless of the number of layers used, the proposed MIFlu model achieves excellent forecasting accuracy, outperforming the SOTA model ReILIF, which has an RMSE of 2431.7 and a PCC of 0.596.

**Fig. 6. Changes in forecasting accuracy according to K.**

*(a) RMSE vs. number of GPT2 layers K (1–7): RMSE decreases from ~2200 at K = 1 to a minimum of ~1920 at K = 4, then increases to ~2030 at K = 7.*
*(b) PCC vs. K (1–7): PCC rises from ~0.56 at K = 1 to a peak of ~0.67 at K = 4, then falls to ~0.60 at K = 7.*

### E. Ablation Study

MIFlu has three core components: a text prompt template, a textual input embedder for multimodality, and a LoRA adapter for fine-tuning. In addition, the text prompt template consists of three sections that describe the dataset, task instructions, and input variables. In the ablation study, we validate the efficacy of these core components by removing each component from pure MIFlu and evaluating the forecasting performance of the model. For the text prompt template, we examine the effect of each section individually. We conduct this study using the National-Illness data.

- **MIFlu w/o Dataset information:** MIFlu without Dataset information part of input text prompt.
- **MIFlu w/o Task instruction:** MIFlu without Task instruction part of input text prompt.
- **MIFlu w/o Input variable description:** MIFlu without Input variable description part of input text prompt.
- **MIFlu w/o LoRA:** MIFlu without the PEFT and fine-tune the forecasting LLM only by updating PE and layer normalization layers.
- **MIFlu w/o multimodality:** MIFlu without the textual input embedder and predict future ILI in unimodality.
- **MIFlu w/o LoRA+multimodality:** MIFlu without the textual input embedder (i.e., predict future ILI in unimodality) and LoRA. We fine-tune the forecasting LLM only by updating PE and layer normalization layers. This setting is the same as GPT4TS [9].

Table VIII shows the results of the ablation study in terms of average MSE and MAE for *L* = 24, 36, 48, and 60. As you can see from the table, removing each part of the input text prompt degrades the forecasting accuracy. This means that all parts of the prompt template in Table I are indispensable. Among the three parts, the input variable description part has the greatest impact on forecasting performance.

**TABLE VIII — Ablation Study Results Using the National-Illness Dataset**

| Schemes | MSE | MAE |
|---------|-----|-----|
| MIFlu | 1.436 | 0.745 |
| MIFlu w/o Dataset information | 1.473 | 0.770 |
| MIFlu w/o Task instruction | 1.465 | 0.759 |
| MIFlu w/o Input variable description | 1.538 | 0.779 |
| MIFlu w/o LoRA | 1.570 | 0.794 |
| MIFlu w/o multimodality | 1.647 | 0.816 |
| MIFlu w/o LoRA+multimodality | 1.925 | 0.904 |

In addition, we observe through MIFlu w/o LoRA that adding LoRA fine-tuning techniques to forecasting LLM improves the forecasting accuracy of GPT4TS even though in unimodality. This seems to be because LLM is pre-trained mainly with text data; therefore, forecasting LLM requires fine-tuning the multi-head self-attention layer using LoRA technique to capture the temporal patterns in historical time-series ILI. In addition, MIFlu w/o multimodal presents that multimodal forecasting improves forecasting performance as forecasting LLM can leverage contextual information encoded by the textual input embedder. However, using both LoRA and multimodal forecasting yields significant performance improvements.

### F. Few-shot Forecasting

To demonstrate the data efficiency of MIFlu, we analyze few-shot forecasting performance in a qualitative manner using the last two seasons of 'ILITOTAL' variable in the National-Illness dataset. Fig. 7(a) and (b) present the normalized forecasting results when using the first 50% (*L* = 48) and 10% (*L* = 24) time steps of training data, respectively. The figures demonstrate that MIFlu achieves significantly better forecasting performance compared to GPT4TS even in the few-shot setting. Especially, MIFlu shows outstanding performance in predicting peak intensity and peak timing, which are extremely important for infectious disease-related decision-making.

**Fig. 7. Few-shot forecasting comparison results using the National-Illness dataset.**

*(a) L = 48, 50% training data — line plot (x-axis: time step 0–100+; y-axis: normalized ILI occurrences) of MIFlu, GPT4TS, and Actual ILI.*
*(b) L = 24, 10% training data — same layout; MIFlu follows peak timing and intensity of the actual ILI more closely than GPT4TS.*

### G. Training Time

Table IX shows the average training time of two regional ILI forecasting models (ReILIF and MIFlu) using the US-Region dataset. Considering the training time of ReILIF is 130 minutes, MIFlu took less time despite being a larger model.

**TABLE IX — Training Time of Regional ILI Forecasting Models**

| Model | Training time (min.) |
|-------|----------------------|
| ReILIF | 130 |
| MIFlu | 119 |

---

## VII. Conclusion

In this paper, we propose MIFlu, a multimodal ILI forecasting scheme based on LLMs. MIFlu can integrate textual domain knowledge from infectious disease experts into a time-series forecasting LLM using a textual input embedder. Through extensive experiments, we demonstrate that MIFlu outperforms other SOTA national/regional ILI forecasting models in most cases. In particular, the proposed scheme improves forecasting performance by up to 26.2% over SOTA models. We also find that the most accurate forecasting performance is achieved when GPT2, which is used as the forecasting LLM, is also used as the textual input embedder. In addition, we analyze the impact of hyperparameters, such as the window size and the number of GPT2 layers, on forecasting accuracy and confirm that the proposed scheme performs well even when changing the number of layers. Finally, we confirm that all components are essential through the ablation study and prove that MIFlu can effectively enhance the forecasting performance of the unimodal model in the few-shot setting.

Even though the proposed model outperforms previously reported models, we utilize a fixed text embedding process from a pre-defined text prompt. In the future, we plan to construct a forecasting model that can fine-tune not only the forecasting LLM but also the textual input embedder to automatically generate suitable text prompts from the input time-series data to further improve short-term ILI forecasting performance.

---

## Appendix: Example of Input Text Prompt

Table X presents the actual example of input text prompt in the case of National-illness dataset.

**TABLE X — Example of an Input Text Prompt**

```
[Dataset information]
This multivariate time series dataset includes 7 features that recorded influenza
patients data from Centers for Disease Control and Prevention of the United States
between 2002 and 2021.
Below (1) to (7) is the information about each feature:
***
[Input variable description]
(1) Percentage of patient visits in the healthcare system attributed to influenza,
adjusted for the proportion of each reporting centers total patient visits. Minimum
value: <min(X1_train)>, maximum value: <max(X1_train)>. This variable peaks 1 time
for 1 year.
(2) Percentage of unweighted influenza, not adjusted for the proportion of each
reporting total patient visits. Minimum value: <min(X2_train)>, maximum value:
<max(X2_train)>. This variable peaks 1 time for 1 year.
(3) Total number of influenza patients between age 0 and 4. Minimum value:
<min(X3_train)>, maximum value: <max(X3_train)>. This variable peaks 1 time for
1 year.
(4) Total number of influenza patients between age 5 and 24. Minimum value:
<min(X4_train)>, maximum value: <max(X4_train)>. This variable peaks 1 time for
1 year.
(5) Total number of influenza patients. Minimum value: <min(X5_train)>, maximum
value: <max(X5_train)>. This variable peaks 1 time for 1 year.
(6) A number of influenza providers. Minimum value: <min(X6_train)>, maximum
value: <max(X6_train)>. This variable peaks 1 time for 1 year. The overall trend
is upward.
(7) 'OT' feature for long-term forecasting task. Minimum value: <min(X7_train)>,
maximum value: <max(X7_train)>. This variable peaks 2 times for 1 year. The
overall trend is upward.
***
[Task instruction]
Predict the next 24 steps given the previous 104 steps for the information attached.
```

---

## References

[1] WHO, "Seasonal influenza newsroom," 2024. [Online]. Available: https://www.who.int/en/news-room/fact-sheets/detail/influenza-(seasonal)

[2] J. Moon, S. Jung, S. Park, and E. Hwang, "Machine learning-based two-stage data selection scheme for long-term influenza forecasting," *Comput. Materials Continua*, vol. 68, no. 3, pp. 2945–2959, 2021, doi: 10.32604/cmc.2021.017435.

[3] S. Deng, S. Wang, H. Rangwala, L. Wang, and Y. Ning, "Cola-GNN: Cross-location attention based graph neural networks for long-term ILI prediction," in *Proc. 29th ACM Int. Conf. Inform. Knowl. Manage.*, 2020, pp. 245–254, doi: 10.1145/3340531.3411975.

[4] Y. Wu, Y. Yang, H. Nishiura, and M. Saitoh, "Deep learning for epidemiological predictions," in *Proc. 41st Int. ACM SIGIR Conf. Res. Develop. Inf. Retrieval*, 2018, pp. 1085–1088, doi: 10.1145/3209978.3210077.

[5] S. Jung, J. Moon, S. Park, and E. Hwang, "Self-attention-based deep learning network for regional influenza forecasting," *IEEE J. Biomed. Health*, vol. 26, no. 2, pp. 922–933, Feb. 2021, doi: 10.1109/JBHI.2021.3093897.

[6] A. Radford, J. Wu, R. Child, D. Luan, D. Amodei, and I. Sutskever, "Language models are unsupervised multitask learners," *OpenAI Blog*, vol. 1, no. 8, 2019, Art. no. 9.

[7] Z. Gu, B. Zhu, G. Zhu, Y. Chen, M. Tang, and J. Wang, "AnomalyGPT: Detecting industrial anomalies using large vision-language models," in *Proc. AAAI Conf. Artif. Intell.*, 2024, pp. 1932–1940, doi: 10.1609/aaai.v38i3.27963.

[8] H. Xue and F. D. Salim, "Promptcast: A new prompt-based learning paradigm for time series forecasting," *IEEE Trans. Knowl. Data Eng.*, vol. 36, no. 11, pp. 6851–6864, Nov. 2024, doi: 10.1109/TKDE.2023.3342137.

[9] T. Zhou, P. Niu, L. Sun, and R. Jin, "One fits all: Power general time series analysis by pre-trained LM," in *Proc. 37th Int. Conf. Neural Inform. Process. Syst.*, 2023, pp. 43322–43355.

[10] J. Moon, S. Jung, S. Park, and E. Hwang, "RESEAT: Recurrent self-attention network for multi-regional influenza forecasting," *IEEE J. Biomed. Health Inform.*, vol. 27, no. 5, pp. 2585–2596, May 2023, doi: 10.1109/JBHI.2023.3247687.

[11] A. Vaswani et al., "Attention is all you need," in *Proc. 31st Int. Conf. Neural Inform. Process. Syst.*, 2017, pp. 6000–6010.

[12] N. Kitaev, Ł. Kaiser, and A. Levskaya, "Reformer: The efficient transformer," 2020, arXiv:2001.04451.

[13] H. Wu, J. Xu, J. Wang, and M. Long, "Autoformer: Decomposition transformers with auto-correlation for long-term series forecasting," in *Proc. 35th Int. Conf. Neural Inform. Process. Syst.*, 2021, pp. 22419–22430.

[14] E. Papagiannopoulou, M. Bossa, N. Deligiannis, and H. Sahli, "Long-term regional influenza-like-illness forecasting using exogenous data," *IEEE J. Biomed. Health Inform.*, vol. 28, no. 6, pp. 3781–3792, Jun. 2024, doi: 10.1109/JBHI.2024.3377529.

[15] J. Devlin, M. W. Chang, K. Lee, and K. Toutanova, "BERT: Pre-training of deep bidirectional transformers for language understanding," in *Proc. ACL Int. Conf. North Amer. Comp. Ling.*, 2019.

[16] A. Radford, K. Narasimhan, T. Salimans, and I. Sutskever, "Improving language understanding by generative pre-training," *OpenAI Blog*, vol. 1, pp. 1–12, 2018.

[17] H. Touvron et al., "Llama 2: Open foundation and fine-tuned chat models," 2023, arXiv:2307.09288.

[18] M. Jin et al., "Time-LLM: Time series forecasting by reprogramming large language models," in *Proc. 12th Int. Conf. Learn. Representations*, 2023. [Online]. Available: https://openreview.net/forum?id=sHXLsv9AOw

[19] T. Kim, J. Kim, Y. Tae, C. Park, J.-H. Choi, and J. Choo, "Reversible instance normalization for accurate time-series forecasting against distribution shift," in *Proc. Int. Conf. Learn. Representations*, 2022. [Online]. Available: https://openreview.net/forum?id=cGDAkQo1C0p

[20] J. Moon, S. Jung, S. Park, and E. Hwang, "Conditional tabular GAN-based two-stage data generation scheme for short-term load forecasting," *IEEE Access*, vol. 8, pp. 205327–205339, 2020, doi: 10.1109/ACCESS.2020.3037063.

[21] N. Houlsby et al., "Parameter-efficient transfer learning for NLP," in *Proc. 36th Int. Conf. Mach. Learn.*, 2019, pp. 2790–2799.

[22] R. Kemker, M. McClure, A. Abitino, T. L. Hayes, and C. Kanan, "Measuring catastrophic forgetting in neural networks," in *Proc. AAAI Conf. Artif. Intell.*, 2018, pp. 3390–3398, doi: 10.1609/AAAI.V32I1.11651.

[23] P. Ye et al., "Partial fine-tuning: A successor to full fine-tuning for vision transformers," 2023, arXiv:2312.15681.

[24] E. Hu et al., "LoRA: Low-rank adaptation of large language models," 2021, arXiv:2106.09685.

[25] Centers for Disease Control and Prevention (CDC), "National, regional, and state level outpatient illness and viral surveillance," 2024. [Online]. Available: https://gis.cdc.gov/grasp/fluview/fluportaldashboard.html

[26] H. Wu, T. Hu, Y. Liu, H. Zhou, J. Wang, and M. Long, "TimesNet: Temporal 2D-variation modeling for general time series analysis," 2022, arXiv:2210.02186.

[27] G. Woo, C. Liu, D. Sahoo, A. Kumar, and S. Hoi, "ETSformer: Exponential smoothing transformers for time-series forecasting," 2022, arXiv:2202.01381.

[28] T. Zhang et al., "Less is more: Fast multivariate time series forecasting with light sampling-oriented MLP structures," 2022, arXiv:2207.01186.

[29] A. Zeng, M. Chen, L. Zhang, and Q. Xu, "Are transformers effective for time series forecasting?" in *Proc. AAAI Conf. Artif. Intell.*, 2023, pp. 10906–10914.

[30] T. Zhou, Z. Ma, Q. Wen, X. Wang, L. Sun, and R. Jin, "FEDformer: Frequency enhanced decomposed transformer for long-term series forecasting," in *Proc. 39th Int. Conf. Mach. Learn.*, 2022, pp. 27268–27286.

[31] Y. Nie, N. H. Nguyen, P. Sinthong, and J. Kalagnanam, "A time series is worth 64 words: Long-term forecasting with transformers," in *Proc. 11th Int. Conf. Learn. Representations*, 2023.

[32] Y. Liu, H. Wu, J. Wang, and M. Long, "Non-stationary transformers: Exploring the stationarity in time series forecasting," in *Proc. 36th Int. Conf. Neural Inform. Process. Syst.*, 2022, pp. 9881–9893.

[33] H. Zhou et al., "Informer: Beyond efficient transformer for long sequence time-series forecasting," in *Proc. AAAI Conf. Artif. Intell.*, 2021, pp. 11106–11115.

[34] B. Lim, S. O. Arık, N. Loeff, and T. Pfister, "Temporal fusion transformers for interpretable multi-horizon time series forecasting," *Int. J. Forecasting*, vol. 37, no. 4, pp. 1748–1764, 2021, doi: 10.1016/j.ijforecast.2021.03.012.

[35] R. Wang, H. Wu, Y. Wu, J. Zheng, and Y. Li, "Improving influenza surveillance based on multi-granularity deep spatiotemporal neural network," *Comput. Biol. Med.*, vol. 134, 2021, Art. no. 104482, doi: 10.1016/j.compbiomed.2021.104482.

[36] C. Chang, W. C. Peng, and T. F. Chen, "LLM4TS: Two-stage fine-tuning for time-series forecasting with pre-trained LLMs," 2023, arXiv:2308.08469.

[37] L. Yang, R. Y. Zhang, Y. Wang, and X. Xie, "MMA: Multi-modal adapter for vision-language models," in *Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit.*, 2024, pp. 23826–23837.
