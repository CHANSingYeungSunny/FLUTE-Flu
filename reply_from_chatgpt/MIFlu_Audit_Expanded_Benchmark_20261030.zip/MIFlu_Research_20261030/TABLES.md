# Generated numeric tables

## B1 archived scores and valid target units

| model | MSE_z_all7 | MAE_z_all7 | MSE_z_ILITOTAL | MSE_counts2_ILITOTAL | MAE_z_ILITOTAL | MAE_counts_ILITOTAL | evidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| miflu | 1.8652 | 0.8842 | 3.7020 | 300071219.8818 | 1.2621 | 11362.5245 | raw predictions independently rescored |
| nlinear | 2.0495 | 0.9566 | NA | NA | NA | NA | aggregate CSV only; target-only errors unavailable |
| dlinear | 2.3478 | 1.0884 | NA | NA | NA | NA | aggregate CSV only; target-only errors unavailable |
| timecma_llm | 2.6700 | 1.0927 | NA | NA | NA | NA | aggregate CSV only; target-only errors unavailable |
| patchtst | 3.9205 | 1.3826 | NA | NA | NA | NA | aggregate CSV only; target-only errors unavailable |
| itransformer | 3.9847 | 1.3545 | NA | NA | NA | NA | aggregate CSV only; target-only errors unavailable |
| qwen_time_llm | 5.2196 | 1.5784 | NA | NA | NA | NA | aggregate CSV only; target-only errors unavailable |
| calf_llm | 5.5153 | 1.6080 | NA | NA | NA | NA | aggregate CSV only; target-only errors unavailable |

## B2 archived window scores

| model | 24 | 36 | 48 | 60 | mean_4L | best_L | worst_L | L60_vs_L24_pct |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| miflu | 1.9686 | 1.9332 | 1.7547 | 1.8042 | 1.8652 | 48 | 24 | -8.35 |
| nlinear | 2.1008 | 2.0277 | 2.0033 | 2.0664 | 2.0495 | 48 | 24 | -1.64 |
| dlinear | 2.2850 | 2.2780 | 2.3558 | 2.4726 | 2.3478 | 36 | 60 | 8.21 |
| timecma_llm | 2.4541 | 2.6432 | 2.7203 | 2.8625 | 2.6700 | 24 | 60 | 16.64 |
| patchtst | 3.8884 | 3.7766 | 3.9525 | 4.0643 | 3.9205 | 36 | 60 | 4.52 |
| itransformer | 3.7511 | 3.9813 | 4.0343 | 4.1721 | 3.9847 | 24 | 60 | 11.23 |
| qwen_time_llm | 4.6187 | 4.9957 | 5.6660 | 5.5978 | 5.2196 | 24 | 48 | 21.20 |
| calf_llm | 5.2711 | 5.3431 | 5.6149 | 5.8321 | 5.5153 | 24 | 60 | 10.64 |

## B2 normalized archived profiles

| model | 24 | 36 | 48 | 60 |
| --- | --- | --- | --- | --- |
| miflu | 1.0554 | 1.0365 | 0.9408 | 0.9673 |
| nlinear | 1.0250 | 0.9893 | 0.9774 | 1.0082 |
| dlinear | 0.9732 | 0.9703 | 1.0034 | 1.0531 |
| timecma_llm | 0.9191 | 0.9900 | 1.0188 | 1.0721 |
| patchtst | 0.9918 | 0.9633 | 1.0082 | 1.0367 |
| itransformer | 0.9414 | 0.9991 | 1.0125 | 1.0470 |
| qwen_time_llm | 0.8849 | 0.9571 | 1.0855 | 1.0725 |
| calf_llm | 0.9557 | 0.9688 | 1.0181 | 1.0574 |

## B3 archived k=1 peak diagnostics

| model | L | mean_PTE_wk | mean_PIE_pct | mean_PTE_le1 | mean_PIE_le25 | mean_combined | n_true | n_matched | n_missed | n_false | n_hit | hit_rate_pct |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| miflu | 24 | 0.2500 | 23.06 | PASS | PASS | PASS | 9 | 8 | 1 | 2 | 5 | 55.56 |
| miflu | 36 | 0.2857 | 24.36 | PASS | PASS | PASS | 9 | 7 | 2 | 3 | 4 | 44.44 |
| miflu | 48 | 0.3750 | 28.42 | PASS | FAIL | FAIL | 9 | 8 | 1 | 1 | 2 | 22.22 |
| miflu | 60 | 0.2857 | 24.69 | PASS | PASS | PASS | 9 | 7 | 2 | 2 | 4 | 44.44 |
| nlinear | 24 | 0.1111 | 3.95 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| nlinear | 36 | 0.3333 | 4.18 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| nlinear | 48 | 0.2222 | 2.42 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| nlinear | 60 | 0.4444 | 2.03 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| dlinear | 24 | 0.8889 | 16.32 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| dlinear | 36 | 1.1111 | 15.86 | FAIL | PASS | FAIL | 9 | 9 | 0 | 0 | 8 | 88.89 |
| dlinear | 48 | 0.7778 | 23.19 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 6 | 66.67 |
| dlinear | 60 | 0.8889 | 15.51 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 8 | 88.89 |
| timecma_llm | 24 | 1.1111 | 42.49 | FAIL | FAIL | FAIL | 9 | 9 | 0 | 2 | 0 | 0.00 |
| timecma_llm | 36 | 1.3750 | 55.55 | FAIL | FAIL | FAIL | 9 | 8 | 1 | 1 | 0 | 0.00 |
| timecma_llm | 48 | 1.3333 | 50.70 | FAIL | FAIL | FAIL | 9 | 9 | 0 | 0 | 0 | 0.00 |
| timecma_llm | 60 | 1.6250 | 52.69 | FAIL | FAIL | FAIL | 9 | 8 | 1 | 1 | 0 | 0.00 |
| patchtst | 24 | 0.5556 | 68.58 | PASS | FAIL | FAIL | 9 | 9 | 0 | 2 | 0 | 0.00 |
| patchtst | 36 | 0.5000 | 61.18 | PASS | FAIL | FAIL | 9 | 4 | 5 | 5 | 0 | 0.00 |
| patchtst | 48 | 1.0000 | 69.36 | PASS | FAIL | FAIL | 9 | 5 | 4 | 4 | 0 | 0.00 |
| patchtst | 60 | 0.7500 | 65.61 | PASS | FAIL | FAIL | 9 | 4 | 5 | 5 | 0 | 0.00 |
| itransformer | 24 | 0.2500 | 65.46 | PASS | FAIL | FAIL | 9 | 4 | 5 | 6 | 0 | 0.00 |
| itransformer | 36 | 0.8333 | 66.34 | PASS | FAIL | FAIL | 9 | 6 | 3 | 3 | 0 | 0.00 |
| itransformer | 48 | 1.0000 | 67.45 | PASS | FAIL | FAIL | 9 | 6 | 3 | 3 | 0 | 0.00 |
| itransformer | 60 | 1.0000 | 66.18 | PASS | FAIL | FAIL | 9 | 4 | 5 | 5 | 0 | 0.00 |
| qwen_time_llm | 24 | 1.1667 | 37.84 | FAIL | FAIL | FAIL | 9 | 6 | 3 | 6 | 0 | 0.00 |
| qwen_time_llm | 36 | 1.0000 | 37.34 | PASS | FAIL | FAIL | 9 | 6 | 3 | 4 | 1 | 11.11 |
| qwen_time_llm | 48 | 0.8333 | 37.80 | PASS | FAIL | FAIL | 9 | 6 | 3 | 3 | 0 | 0.00 |
| qwen_time_llm | 60 | 0.8333 | 32.34 | PASS | FAIL | FAIL | 9 | 6 | 3 | 3 | 0 | 0.00 |
| calf_llm | 24 | 2.0000 | 79.64 | FAIL | FAIL | FAIL | 9 | 1 | 8 | 11 | 0 | 0.00 |
| calf_llm | 36 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 9 | 0 | 0.00 |
| calf_llm | 48 | 0.2000 | 82.72 | PASS | FAIL | FAIL | 9 | 5 | 4 | 5 | 0 | 0.00 |
| calf_llm | 60 | 1.3333 | 80.56 | FAIL | FAIL | FAIL | 9 | 3 | 6 | 6 | 0 | 0.00 |

## New expanded per-L scores

| model | L | mse_z_all7 | mae_z_all7 | mse_z_ili | mae_z_ili | mse_counts2_ili | mae_counts_ili |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Autoformer | 24 | 3.6945 | 1.3920 | 7.8148 | 2.0500 | 633442378.9201 | 18456.2241 |
| Autoformer | 36 | 3.6592 | 1.3702 | 7.7567 | 2.0045 | 628730100.1348 | 18047.0463 |
| Autoformer | 48 | 3.8045 | 1.4015 | 8.0330 | 2.0085 | 651130883.2220 | 18082.4848 |
| Autoformer | 60 | 3.9944 | 1.4369 | 8.5341 | 2.0593 | 691743262.3534 | 18539.9762 |
| CNN | 24 | 2.3132 | 0.9549 | 4.7991 | 1.3990 | 389003066.2854 | 12595.0329 |
| CNN | 36 | 2.1830 | 0.9164 | 4.4843 | 1.2761 | 363481187.6908 | 11488.9079 |
| CNN | 48 | 2.1552 | 0.9175 | 4.3977 | 1.2418 | 356460378.4120 | 11179.6846 |
| CNN | 60 | 2.1020 | 0.9053 | 4.3318 | 1.2307 | 351120774.7502 | 11079.7408 |
| DNN | 24 | 2.8999 | 1.0712 | 5.8687 | 1.6383 | 475698432.2130 | 14749.8812 |
| DNN | 36 | 2.6293 | 1.0780 | 5.3857 | 1.6649 | 436549202.0532 | 14989.4014 |
| DNN | 48 | 2.6089 | 1.1134 | 5.2185 | 1.6886 | 422994407.5860 | 15202.4637 |
| DNN | 60 | 2.6696 | 1.1350 | 5.4157 | 1.7353 | 438981511.0915 | 15623.3279 |
| DecisionTree | 24 | 4.6968 | 1.4817 | 8.9657 | 1.8379 | 726726907.9027 | 16546.7389 |
| DecisionTree | 36 | 5.4421 | 1.5919 | 10.4024 | 2.0433 | 843182373.3586 | 18396.2688 |
| DecisionTree | 48 | 5.7069 | 1.6690 | 11.0804 | 2.1161 | 898140367.0046 | 19051.8750 |
| DecisionTree | 60 | 5.4278 | 1.6154 | 10.7819 | 2.1159 | 873942193.3472 | 19050.0065 |
| GRU | 24 | 2.3005 | 1.0030 | 4.5976 | 1.4305 | 372662856.6124 | 12879.1119 |
| GRU | 36 | 2.3769 | 0.9990 | 4.8510 | 1.3993 | 393204309.6469 | 12597.8817 |
| GRU | 48 | 2.2360 | 0.9738 | 4.5004 | 1.3397 | 364785039.7091 | 12061.4225 |
| GRU | 60 | 2.3145 | 0.9755 | 4.7547 | 1.3563 | 385404344.1547 | 12210.6642 |
| KNN | 24 | 3.8106 | 1.3452 | 7.1808 | 1.7621 | 582055648.5992 | 15864.8247 |
| KNN | 36 | 3.8004 | 1.3372 | 7.2891 | 1.7730 | 590830089.4564 | 15962.7123 |
| KNN | 48 | 3.9171 | 1.3699 | 7.6660 | 1.8360 | 621384300.3416 | 16529.5344 |
| KNN | 60 | 4.0096 | 1.3901 | 7.9668 | 1.8758 | 645763740.1122 | 16888.5390 |
| NLinear | 24 | 2.1115 | 0.9554 | 4.1638 | 1.3373 | 337508122.7060 | 12039.9183 |
| NLinear | 36 | 2.0096 | 0.9408 | 3.9364 | 1.2759 | 319070244.2010 | 11487.4675 |
| NLinear | 48 | 2.0682 | 0.9682 | 4.0648 | 1.3079 | 329482307.4615 | 11775.5074 |
| NLinear | 60 | 2.0754 | 0.9737 | 4.0974 | 1.3106 | 332122877.4350 | 11799.3681 |
| PCA-HistGB | 24 | 4.0101 | 1.3412 | 7.8954 | 1.6961 | 639972074.8478 | 15270.3307 |
| PCA-HistGB | 36 | 4.4695 | 1.3984 | 9.0316 | 1.8242 | 732071322.8693 | 16423.8332 |
| PCA-HistGB | 48 | 4.6324 | 1.4463 | 9.4196 | 1.9018 | 763524137.9327 | 17121.8692 |
| PCA-HistGB | 60 | 5.0105 | 1.5143 | 10.2416 | 2.0178 | 830150293.4695 | 18166.9095 |
| PCA-SVR | 24 | 5.6845 | 1.6136 | 10.4875 | 2.0601 | 850086703.3437 | 18547.6840 |
| PCA-SVR | 36 | 5.7753 | 1.6303 | 10.8244 | 2.0884 | 877386936.8938 | 18802.3383 |
| PCA-SVR | 48 | 5.9202 | 1.6573 | 11.3254 | 2.1421 | 918002999.9627 | 19285.8204 |
| PCA-SVR | 60 | 6.0664 | 1.6902 | 11.7660 | 2.1998 | 953716570.6836 | 19804.8585 |
| PeakBlend | 24 | 2.5589 | 1.0505 | 5.3718 | 1.5467 | 435418642.5945 | 13925.4282 |
| PeakBlend | 36 | 1.9932 | 0.9315 | 3.9456 | 1.2611 | 319818348.8502 | 11354.3154 |
| PeakBlend | 48 | 2.3318 | 0.9976 | 4.8081 | 1.3873 | 389731391.7675 | 12490.2360 |
| PeakBlend | 60 | 1.8983 | 0.9147 | 3.7491 | 1.2219 | 303888763.9182 | 11000.9264 |
| RandomForest | 24 | 3.8991 | 1.3716 | 7.2653 | 1.5974 | 588902318.4165 | 14381.8173 |
| RandomForest | 36 | 4.5019 | 1.4137 | 8.7845 | 1.7720 | 712043382.4410 | 15953.6885 |
| RandomForest | 48 | 4.8681 | 1.4756 | 9.7091 | 1.8882 | 786988680.7351 | 16999.6929 |
| RandomForest | 60 | 5.2700 | 1.5581 | 10.5775 | 2.0437 | 857379004.9565 | 18399.5189 |
| TimesNet | 24 | 2.7961 | 1.0693 | 5.9901 | 1.5986 | 485537033.5955 | 14392.2882 |
| TimesNet | 36 | 2.1290 | 0.9506 | 4.3576 | 1.3137 | 353215573.7112 | 11827.8494 |
| TimesNet | 48 | 2.8846 | 1.0936 | 6.2632 | 1.5988 | 507672550.3142 | 14394.2788 |
| TimesNet | 60 | 2.0020 | 0.9296 | 4.0209 | 1.2652 | 325919756.1391 | 11390.4564 |

## New expanded means

| model | mse_z_all7 | mae_z_all7 | mse_z_ili | mae_z_ili | mse_counts2_ili | mae_counts_ili | sd_seed_MSE_all7 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| NLinear | 2.0662 | 0.9595 | 4.0656 | 1.3079 | 329545887.9509 | 11775.5654 | 0.0228 |
| CNN | 2.1883 | 0.9235 | 4.5032 | 1.2869 | 365016351.7846 | 11585.8415 | 0.0728 |
| PeakBlend | 2.1955 | 0.9736 | 4.4687 | 1.3543 | 362214286.7826 | 12192.7265 | 0.2590 |
| GRU | 2.3069 | 0.9878 | 4.6759 | 1.3814 | 379014137.5308 | 12437.2701 | 0.0967 |
| TimesNet | 2.4529 | 1.0108 | 5.1579 | 1.4441 | 418086228.4400 | 13001.2182 | 0.4815 |
| DNN | 2.7019 | 1.0994 | 5.4722 | 1.6818 | 443555888.2359 | 15141.2686 | 0.0270 |
| Autoformer | 3.7881 | 1.4002 | 8.0346 | 2.0306 | 651261656.1576 | 18281.4329 | 0.0180 |
| KNN | 3.8844 | 1.3606 | 7.5257 | 1.8117 | 610008444.6273 | 16311.4026 | 0.0000 |
| PCA-HistGB | 4.5306 | 1.4250 | 9.1470 | 1.8600 | 741429457.2798 | 16745.7357 | 0.0000 |
| RandomForest | 4.6348 | 1.4547 | 9.0841 | 1.8253 | 736328346.6373 | 16433.6794 | 0.0236 |
| DecisionTree | 5.3184 | 1.5895 | 10.3076 | 2.0283 | 835497960.4033 | 18261.2223 | 0.0534 |
| PCA-SVR | 5.8616 | 1.6478 | 11.1008 | 2.1226 | 899798302.7210 | 19110.1753 | 0.0000 |

## New expanded best and worst windows

| model | 24 | 36 | 48 | 60 | mean_4L | best_L | worst_L |
| --- | --- | --- | --- | --- | --- | --- | --- |
| NLinear | 2.1115 | 2.0096 | 2.0682 | 2.0754 | 2.0662 | 36 | 24 |
| CNN | 2.3132 | 2.1830 | 2.1552 | 2.1020 | 2.1883 | 60 | 24 |
| PeakBlend | 2.5589 | 1.9932 | 2.3318 | 1.8983 | 2.1955 | 60 | 24 |
| GRU | 2.3005 | 2.3769 | 2.2360 | 2.3145 | 2.3069 | 48 | 36 |
| TimesNet | 2.7961 | 2.1290 | 2.8846 | 2.0020 | 2.4529 | 60 | 48 |
| DNN | 2.8999 | 2.6293 | 2.6089 | 2.6696 | 2.7019 | 48 | 24 |
| Autoformer | 3.6945 | 3.6592 | 3.8045 | 3.9944 | 3.7881 | 36 | 60 |
| KNN | 3.8106 | 3.8004 | 3.9171 | 4.0096 | 3.8844 | 36 | 60 |
| PCA-HistGB | 4.0101 | 4.4695 | 4.6324 | 5.0105 | 4.5306 | 24 | 60 |
| RandomForest | 3.8991 | 4.5019 | 4.8681 | 5.2700 | 4.6348 | 24 | 60 |
| DecisionTree | 4.6968 | 5.4421 | 5.7069 | 5.4278 | 5.3184 | 24 | 48 |
| PCA-SVR | 5.6845 | 5.7753 | 5.9202 | 6.0664 | 5.8616 | 24 | 60 |

## New expanded normalized profiles

| model | 24 | 36 | 48 | 60 |
| --- | --- | --- | --- | --- |
| NLinear | 1.0219 | 0.9726 | 1.0010 | 1.0045 |
| CNN | 1.0570 | 0.9976 | 0.9848 | 0.9606 |
| PeakBlend | 1.1655 | 0.9078 | 1.0620 | 0.8646 |
| GRU | 0.9972 | 1.0303 | 0.9692 | 1.0033 |
| TimesNet | 1.1399 | 0.8680 | 1.1760 | 0.8162 |
| DNN | 1.0733 | 0.9731 | 0.9656 | 0.9880 |
| Autoformer | 0.9753 | 0.9660 | 1.0043 | 1.0544 |
| KNN | 0.9810 | 0.9784 | 1.0084 | 1.0322 |
| PCA-HistGB | 0.8851 | 0.9865 | 1.0225 | 1.1059 |
| RandomForest | 0.8413 | 0.9713 | 1.0504 | 1.1371 |
| DecisionTree | 0.8831 | 1.0233 | 1.0730 | 1.0206 |
| PCA-SVR | 0.9698 | 0.9853 | 1.0100 | 1.0349 |

## New expanded per-L peak diagnostics

| model | L | mean_PTE_wk | mean_PIE_pct | mean_PTE_le1 | mean_PIE_le25 | mean_combined | n_true | n_matched | n_missed | n_false | n_hit | hit_rate_pct |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DecisionTree | 24 | 1.0000 | 72.96 | PASS | FAIL | FAIL | 9 | 1 | 8 | 14 | 0 | 0.00 |
| DecisionTree | 36 | 2.0000 | 57.63 | FAIL | FAIL | FAIL | 9 | 1 | 8 | 5 | 0 | 0.00 |
| DecisionTree | 48 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 3 | 0 | 0.00 |
| DecisionTree | 60 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 15 | 0 | 0.00 |
| RandomForest | 24 | 1.2000 | 67.19 | FAIL | FAIL | FAIL | 9 | 5 | 4 | 6 | 0 | 0.00 |
| RandomForest | 36 | 1.5000 | 84.62 | FAIL | FAIL | FAIL | 9 | 2 | 7 | 8 | 0 | 0.00 |
| RandomForest | 48 | 1.0000 | 82.59 | PASS | FAIL | FAIL | 9 | 4 | 5 | 5 | 0 | 0.00 |
| RandomForest | 60 | 0.6667 | 84.36 | PASS | FAIL | FAIL | 9 | 3 | 6 | 6 | 0 | 0.00 |
| PCA-HistGB | 24 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 9 | 0 | 0.00 |
| PCA-HistGB | 36 | 1.0000 | 72.90 | PASS | FAIL | FAIL | 9 | 6 | 3 | 3 | 0 | 0.00 |
| PCA-HistGB | 48 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 9 | 0 | 0.00 |
| PCA-HistGB | 60 | 2.0000 | 75.03 | FAIL | FAIL | FAIL | 9 | 3 | 6 | 6 | 0 | 0.00 |
| PCA-SVR | 24 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 9 | 0 | 0.00 |
| PCA-SVR | 36 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 9 | 0 | 0.00 |
| PCA-SVR | 48 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 9 | 0 | 0.00 |
| PCA-SVR | 60 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 6 | 0 | 0.00 |
| KNN | 24 | 2.0000 | 64.52 | FAIL | FAIL | FAIL | 9 | 3 | 6 | 6 | 0 | 0.00 |
| KNN | 36 | 2.0000 | 65.23 | FAIL | FAIL | FAIL | 9 | 3 | 6 | 6 | 0 | 0.00 |
| KNN | 48 | 2.0000 | 67.47 | FAIL | FAIL | FAIL | 9 | 3 | 6 | 6 | 0 | 0.00 |
| KNN | 60 | 2.0000 | 67.47 | FAIL | FAIL | FAIL | 9 | 3 | 6 | 6 | 0 | 0.00 |
| NLinear | 24 | 0.6667 | 2.09 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| NLinear | 36 | 0.4444 | 4.18 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| NLinear | 48 | 0.5556 | 1.67 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| NLinear | 60 | 0.6667 | 3.68 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| DNN | 24 | 0.5000 | 21.87 | PASS | PASS | PASS | 9 | 8 | 1 | 5 | 5 | 55.56 |
| DNN | 36 | 0.6000 | 25.93 | PASS | FAIL | FAIL | 9 | 5 | 4 | 4 | 2 | 22.22 |
| DNN | 48 | 0.5556 | 27.41 | PASS | FAIL | FAIL | 9 | 9 | 0 | 4 | 3 | 33.33 |
| DNN | 60 | 0.8750 | 26.79 | PASS | FAIL | FAIL | 9 | 8 | 1 | 5 | 2 | 22.22 |
| CNN | 24 | 1.1667 | 49.04 | FAIL | FAIL | FAIL | 9 | 6 | 3 | 7 | 0 | 0.00 |
| CNN | 36 | 1.2857 | 50.80 | FAIL | FAIL | FAIL | 9 | 7 | 2 | 2 | 0 | 0.00 |
| CNN | 48 | 1.2857 | 51.85 | FAIL | FAIL | FAIL | 9 | 7 | 2 | 2 | 0 | 0.00 |
| CNN | 60 | 1.5714 | 52.07 | FAIL | FAIL | FAIL | 9 | 7 | 2 | 2 | 0 | 0.00 |
| GRU | 24 | 1.1429 | 30.97 | FAIL | FAIL | FAIL | 9 | 7 | 2 | 5 | 2 | 22.22 |
| GRU | 36 | 1.0000 | 37.45 | PASS | FAIL | FAIL | 9 | 7 | 2 | 4 | 1 | 11.11 |
| GRU | 48 | 1.1667 | 44.13 | FAIL | FAIL | FAIL | 9 | 6 | 3 | 3 | 0 | 0.00 |
| GRU | 60 | 1.0000 | 41.30 | PASS | FAIL | FAIL | 9 | 9 | 0 | 0 | 0 | 0.00 |
| TimesNet | 24 | 1.3333 | 27.17 | FAIL | FAIL | FAIL | 9 | 6 | 3 | 7 | 1 | 11.11 |
| TimesNet | 36 | 0.6000 | 39.89 | PASS | FAIL | FAIL | 9 | 5 | 4 | 6 | 1 | 11.11 |
| TimesNet | 48 | 1.2000 | 36.81 | FAIL | FAIL | FAIL | 9 | 5 | 4 | 8 | 1 | 11.11 |
| TimesNet | 60 | 1.0000 | 39.39 | PASS | FAIL | FAIL | 9 | 8 | 1 | 2 | 1 | 11.11 |
| Autoformer | 24 | 1.0000 | 66.88 | PASS | FAIL | FAIL | 9 | 3 | 6 | 12 | 0 | 0.00 |
| Autoformer | 36 | 1.3333 | 58.25 | FAIL | FAIL | FAIL | 9 | 3 | 6 | 13 | 0 | 0.00 |
| Autoformer | 48 | NA | NA | NA | NA | NA | 9 | 0 | 9 | 14 | 0 | 0.00 |
| Autoformer | 60 | 1.0000 | 73.95 | PASS | FAIL | FAIL | 9 | 3 | 6 | 10 | 0 | 0.00 |
| PeakBlend | 24 | 0.6667 | 2.10 | PASS | PASS | PASS | 9 | 9 | 0 | 6 | 9 | 100.00 |
| PeakBlend | 36 | 0.4444 | 4.24 | PASS | PASS | PASS | 9 | 9 | 0 | 0 | 9 | 100.00 |
| PeakBlend | 48 | 0.5556 | 1.72 | PASS | PASS | PASS | 9 | 9 | 0 | 1 | 9 | 100.00 |
| PeakBlend | 60 | 0.6667 | 9.77 | PASS | PASS | PASS | 9 | 9 | 0 | 1 | 9 | 100.00 |

## New actual terminal-lead peak diagnostics

| model | L | mean_PTE_wk | mean_PIE_pct | mean_PTE_le1 | mean_PIE_le25 | mean_combined | n_true | n_matched | n_missed | n_false | n_hit | hit_rate_pct |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DecisionTree | 24 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 6 | 0 | 0.00 |
| DecisionTree | 36 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 14 | 0 | 0.00 |
| DecisionTree | 48 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 15 | 0 | 0.00 |
| DecisionTree | 60 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 6 | 0 | 0.00 |
| RandomForest | 24 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 9 | 0 | 0.00 |
| RandomForest | 36 | 2.0000 | 80.75 | FAIL | FAIL | FAIL | 6 | 1 | 5 | 7 | 0 | 0.00 |
| RandomForest | 48 | 2.0000 | 80.01 | FAIL | FAIL | FAIL | 6 | 2 | 4 | 7 | 0 | 0.00 |
| RandomForest | 60 | 1.0000 | 84.31 | PASS | FAIL | FAIL | 6 | 3 | 3 | 3 | 0 | 0.00 |
| PCA-HistGB | 24 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 6 | 0 | 0.00 |
| PCA-HistGB | 36 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 6 | 0 | 0.00 |
| PCA-HistGB | 48 | 1.5000 | 76.21 | FAIL | FAIL | FAIL | 6 | 6 | 0 | 3 | 0 | 0.00 |
| PCA-HistGB | 60 | 1.0000 | 72.74 | PASS | FAIL | FAIL | 6 | 6 | 0 | 3 | 0 | 0.00 |
| PCA-SVR | 24 | 2.0000 | 88.63 | FAIL | FAIL | FAIL | 6 | 3 | 3 | 3 | 0 | 0.00 |
| PCA-SVR | 36 | 2.0000 | 80.66 | FAIL | FAIL | FAIL | 6 | 6 | 0 | 0 | 0 | 0.00 |
| PCA-SVR | 48 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 9 | 0 | 0.00 |
| PCA-SVR | 60 | 1.0000 | 74.54 | PASS | FAIL | FAIL | 6 | 6 | 0 | 0 | 0 | 0.00 |
| KNN | 24 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 6 | 0 | 0.00 |
| KNN | 36 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 6 | 0 | 0.00 |
| KNN | 48 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 6 | 0 | 0.00 |
| KNN | 60 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 6 | 0 | 0.00 |
| NLinear | 24 | 1.2500 | 42.82 | FAIL | FAIL | FAIL | 6 | 4 | 2 | 5 | 0 | 0.00 |
| NLinear | 36 | 0.4000 | 43.76 | PASS | FAIL | FAIL | 6 | 5 | 1 | 4 | 0 | 0.00 |
| NLinear | 48 | 1.0000 | 40.84 | PASS | FAIL | FAIL | 6 | 6 | 0 | 3 | 0 | 0.00 |
| NLinear | 60 | 1.5000 | 55.40 | FAIL | FAIL | FAIL | 6 | 2 | 4 | 7 | 0 | 0.00 |
| DNN | 24 | 0.4000 | 31.76 | PASS | FAIL | FAIL | 6 | 5 | 1 | 6 | 2 | 33.33 |
| DNN | 36 | 1.0000 | 23.60 | PASS | PASS | PASS | 6 | 3 | 3 | 8 | 1 | 16.67 |
| DNN | 48 | 1.0000 | 27.67 | PASS | FAIL | FAIL | 6 | 3 | 3 | 7 | 1 | 16.67 |
| DNN | 60 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 10 | 0 | 0.00 |
| CNN | 24 | 1.5000 | 52.06 | FAIL | FAIL | FAIL | 6 | 4 | 2 | 5 | 0 | 0.00 |
| CNN | 36 | 1.0000 | 54.28 | PASS | FAIL | FAIL | 6 | 2 | 4 | 7 | 0 | 0.00 |
| CNN | 48 | 1.0000 | 58.54 | PASS | FAIL | FAIL | 6 | 2 | 4 | 7 | 0 | 0.00 |
| CNN | 60 | 0.0000 | 56.40 | PASS | FAIL | FAIL | 6 | 1 | 5 | 8 | 0 | 0.00 |
| GRU | 24 | 1.2500 | 61.04 | FAIL | FAIL | FAIL | 6 | 4 | 2 | 5 | 0 | 0.00 |
| GRU | 36 | 0.3333 | 54.69 | PASS | FAIL | FAIL | 6 | 3 | 3 | 6 | 0 | 0.00 |
| GRU | 48 | 0.7500 | 53.76 | PASS | FAIL | FAIL | 6 | 4 | 2 | 5 | 0 | 0.00 |
| GRU | 60 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 9 | 0 | 0.00 |
| TimesNet | 24 | 1.6000 | 30.83 | FAIL | FAIL | FAIL | 6 | 5 | 1 | 5 | 0 | 0.00 |
| TimesNet | 36 | 1.6667 | 46.92 | FAIL | FAIL | FAIL | 6 | 3 | 3 | 6 | 0 | 0.00 |
| TimesNet | 48 | 0.7500 | 47.83 | PASS | FAIL | FAIL | 6 | 4 | 2 | 6 | 0 | 0.00 |
| TimesNet | 60 | 1.0000 | 47.38 | PASS | FAIL | FAIL | 6 | 1 | 5 | 10 | 0 | 0.00 |
| Autoformer | 24 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 13 | 0 | 0.00 |
| Autoformer | 36 | 1.5000 | 57.16 | FAIL | FAIL | FAIL | 6 | 4 | 2 | 6 | 0 | 0.00 |
| Autoformer | 48 | NA | NA | NA | NA | NA | 6 | 0 | 6 | 11 | 0 | 0.00 |
| Autoformer | 60 | 1.0000 | 76.09 | PASS | FAIL | FAIL | 6 | 2 | 4 | 10 | 0 | 0.00 |
| PeakBlend | 24 | 1.6000 | 32.07 | FAIL | FAIL | FAIL | 6 | 5 | 1 | 5 | 0 | 0.00 |
| PeakBlend | 36 | 1.2500 | 45.95 | FAIL | FAIL | FAIL | 6 | 4 | 2 | 5 | 0 | 0.00 |
| PeakBlend | 48 | 1.3333 | 42.42 | FAIL | FAIL | FAIL | 6 | 6 | 0 | 3 | 0 | 0.00 |
| PeakBlend | 60 | 0.5000 | 53.50 | PASS | FAIL | FAIL | 6 | 2 | 4 | 7 | 0 | 0.00 |

## New expanded cost summary

| model | fit_val_seconds_mean | fit_val_seconds_total | inference_ms_per_origin | gpu_hours_total | parameters_min | parameters_max | FLOPs | uses_text |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Autoformer | 13.3873 | 160.6481 | 0.3267 | 0.0000 | 6631.0000 | 6631.0000 | unmeasured | False |
| CNN | 1.4230 | 17.0762 | 0.0346 | 0.0000 | 36984.0000 | 89652.0000 | unmeasured | False |
| DNN | 0.9299 | 11.1584 | 0.0163 | 0.0000 | 61736.0000 | 78116.0000 | unmeasured | False |
| DecisionTree | 1.6463 | 19.7550 | 0.0024 | 0.0000 | NA | NA | unmeasured | False |
| GRU | 11.7678 | 141.2139 | 0.1010 | 0.0000 | 9480.0000 | 17796.0000 | unmeasured | False |
| KNN | 0.0138 | 0.1651 | 0.0516 | 0.0000 | NA | NA | unmeasured | False |
| NLinear | 0.6556 | 7.8667 | 0.0040 | 0.0000 | 2520.0000 | 6300.0000 | unmeasured | False |
| PCA-HistGB | 6.3443 | 76.1312 | 0.0453 | 0.0000 | NA | NA | unmeasured | False |
| PCA-SVR | 0.7890 | 9.4683 | 1.2330 | 0.0000 | NA | NA | unmeasured | False |
| RandomForest | 11.0941 | 133.1293 | 0.1480 | 0.0000 | NA | NA | unmeasured | False |
| TimesNet | 9.9350 | 119.2202 | 0.3184 | 0.0000 | 24327.0000 | 28107.0000 | unmeasured | False |