# MIFlu audit + exploratory expanded benchmark — 30 October 2026

**PARTIAL_REPRODUCTION.** This is a research supplement, not a replacement for the frozen authoritative DOCX/MD. Start with `MIFlu_Research_Supplement_20261030.md`. Every new result is exploratory; no new SOTA-LLM experiment or MIFlu GPU retraining is claimed.

## What is included

- Unchanged original handoff zip in `input/`; extract to `handoff/` using the command below.
- Audit/scoring code, per-model × window tables, ILITOTAL physical-unit calculations, true-lead diagnostics, model cost tables, four scientific figures in PNG + PDF, and full experiment logs.
- 132 newly trained CPU cells: 11 models × four output lengths × three seeds. NLinear is the only learned linear baseline in this suite. Classical models include a decision tree, random forest, target-PCA histogram gradient boosting, target-PCA SVR and KNN. Neural models include DNN, CNN, GRU, TimesNet and Autoformer.
- 12 exploratory PeakBlend evaluations using already trained NLinear and TimesNet experts; validation-fitted gate, predictions and all gate candidates retained.
- Per-cell prediction arrays, targets, origins and selected neural states. Classical models can be refitted from the locked configuration; their predictions and validation choices are saved.
- A separately prepared C2 scheduler-alignment MIFlu trainer, **not run**, requiring the missing original `r1b_model.py`.
- A compatible-checkpoint local LLM feature runner, **not run**. DeepSeek custom/MoE backends and commercial API arms require separate implementation/validation.

## Important corrections before using any number

1. National-Illness is **US CDC**, not Hong Kong data. The DOI title is *MIFlu: Large Language Model-Based Multimodal Influenza Forecasting Scheme*.
2. Archived MSE 1.8652 averages **seven variables**. It cannot be converted to ILITOTAL patient-count MSE by multiplying by 9003.15². The supplement supplies valid target-only errors wherever raw predictions exist; the other seven archived models lack those raw files.
3. L=24/36/48/60 is output-window length. Archived peak tables use **actual lead k=1** from each model. Actual terminal-lead diagnostics are provided separately.
4. The supplied strict peak event CSVs show **15/36** MIFlu hits. The prompt's **31/36 CONSENSUS** remains unverified because `peak_criteria.json` is absent. In packaged tables, 31/36 belongs to DLinear. No version is silently substituted for the unavailable consensus.
5. Text tokens vary within each 317×768 matrix; the matrix is static across samples. The text-path GPU/CPU contradiction remains **UNRESOLVED**.
6. The paper, Track R and Track C have different protocols. The apparent 29.93% separation is descriptive, not a controlled estimate of a reproducibility error.

## Reproduce saved results without training

Use Python 3.12. The exact measured environment is in `results/expanded/environment.json`; software versions are pinned in `requirements-analysis.txt` and `requirements-training.txt`.

```bash
python -m zipfile -e input/MLFlu_ChatGPT_Handoff_20261030.zip handoff
python -m pip install -r requirements-analysis.txt
python code/audit.py --handoff handoff --out results
python code/test_contract.py
python code/scheduler_contract.py --out results/scheduler_timeline.csv
python code/build_supplement.py --handoff handoff --output .
python code/verify_delivery.py --handoff handoff --output .
```

Replaying the saved new-model results requires only analysis dependencies. Executing the mechanism probe or training needs PyTorch. Verification checks all 144 new cell predictions, full targets, strict origins, selected validation winners/checkpoints, and preservation of every original input file. It does not imply the missing/optional models executed.

## Retrain the expanded suite

Create a clean virtual environment and install `requirements-training.txt`. CPU runs were measured with two intra-op/BLAS threads. Hardware and concurrent load affect timing; exact floating results may vary by PyTorch version, CPU instruction set and thread implementation.

Existing completed cell outputs are resumed only when the configuration hash matches. To perform an independent rerun, use a **new output directory** (for example `rerun/expanded`); do not overwrite frozen evidence.

```bash
python code/run_expanded.py --handoff handoff --out rerun/expanded --config protocol/config.json --models DecisionTree,RandomForest,PCA-HistGB,PCA-SVR,KNN,NLinear,DNN,CNN,GRU --device cpu
python code/run_expanded.py --handoff handoff --out rerun/timesnet --config protocol/config.json --models TimesNet --device cpu
python code/run_expanded.py --handoff handoff --out rerun/autoformer --config protocol/autoformer_config.json --models Autoformer --device cpu
python code/run_hybrid.py --handoff handoff --expanded rerun/expanded --timesnet rerun/timesnet --out rerun/hybrid --config protocol/hybrid_config.json
```

The existing base and TimesNet processes loaded the supplied `runtime_snapshot_run_expanded_v1.py`. While they ran, the active file was extended only to add Autoformer; Autoformer used the final `run_expanded.py`. The v1 runtime snapshot and final source are both retained. Their existing-model behavior is unchanged. Configuration hashes and vendor source commit are recorded. These are observed execution records, not a retroactive claim of a prospective preregistration.

The raw state files are PyTorch state dictionaries; load only these supplied/trusted artifacts with `weights_only=True`. The LLM runner never requires a pickle checkpoint from an unknown source.

## Resume reproduction-gap experiments on the authorized HPC environment

Current environment blockers were checked: `HPC_GUIDE.md` is missing from this archive; no SSH keys are configured here; the host `burgundy.hpc.cityu.edu.hk` fails DNS resolution. No job was submitted. The handoff also lacks `r1b_model.py`, the original corrected MIFlu module imported by its trainer. An existing `hpc_submit.sh` is not a substitute for verified current cluster guidance.

Restore these files/access from the original project and run from the environment where passwordless SSH already works. Do not substitute the separate `miflu_model.py` reconstruction and call it an exact rerun. Retrieve original software/checkpoint fingerprints before matching CPU/GPU mechanism traces.

The new C2 candidate is in `code/candidate_c2_train.py`. Its schedule matches the author's end-of-previous-epoch update, whereas packaged R1C applies that update one epoch early. Use a new output path on the verified compute node:

```bash
python code/candidate_c2_train.py --code-root /path/to/author/code --data /path/to/author/code/dataset/illness/national_illness.csv --r1b /path/to/recovered/r1b_module_dir --horizon 24 --seed 42 --device cuda --out /path/to/new/C2_L24_seed42
```

Repeat all four horizons and the same frozen seeds; expand to ten repetitions for paper-oriented estimates. Report C2 separately from Track C and compare only paired arms with the same experimental contract. No claimed C2 score exists in this delivery.

## LLM continuation

`results/llm_execution_status.csv` records every requested unrun family and its blocker. A paired local encoding/generation runner for compatible immutable snapshots is supplied:

```bash
python code/run_llm_features.py --handoff handoff --out new_llm_arm --snapshot /absolute/path/to/approved/local/snapshot --model-id Qwen/Qwen2.5-1.5B-Instruct --revision IMMUTABLE_MODEL_COMMIT --device cuda
```

Run no-text numerical-summary and sham-text controls with the same downstream capacity before attributing any gain to semantics or reasoning. All generated features must use only observed inputs and legally available as-of-origin external text. The code uses concise structured analysis rather than relying on inaccessible internal reasoning. It requires local weights and compatible `transformers`; no model weights, API credentials or API results are included. Model cards and license/access checks must be resolved on the actual HPC environment. Full DeepSeek-V3 is not treated as a single-GPU baseline; DeepSeek-V2-Lite is a separate resource-scaled comparator. No future scheduled job is implied.

## Scope of statistics

Three seeds are not three independent influenza datasets. Four windows share observations, and the 36 peak records reuse three underlying peaks. Deterministic classical estimators repeat identically. Seed SDs capture only optimization variability. Confirmatory season/block inference, additional unseen data, calibration and real forecast issuance remain outstanding.

## File map

| Location | Purpose |
| --- | --- |
| `MIFlu_Research_Supplement_20261030.md` | Academic-structure audit, all requested tables, interpretation, limitations |
| `TABLES.md` | Numeric Markdown tables for copying |
| `results/audit_summary.json` | Core independently checked audit values |
| `results/expanded_all_cells.csv` | 144 new cells including the hybrid |
| `results/expanded_all_per_L.csv` | New MSE/MAE in both valid spaces per model/L |
| `results/expanded_all_peak_by_L.csv` | New peak metrics and denominators per model/L |
| `results/expanded_cost_summary.csv` | Measured CPU costs, neural parameters, unmeasured FLOPs explicitly labelled |
| `results/delivery_verification.json` | Verification verdict |
| `figures/` | Four plots, PNG and vector PDF |
| `logs/` | Training and contract-test outputs |
| `protocol/` | Frozen configuration files and continuation specification |
| `code/vendor/tslib/` | Pinned upstream Autoformer/TimesNet sources + MIT license |

This bundle is a reproducible exploratory research artifact. It is not evidence of completed full reproduction, an executed modern-LLM benchmark, prospective epidemiological validity or guaranteed suitability for a top-tier journal.
