"""Exploratory input-causal peak-aware mixture; no MIFlu retraining is implied."""
import argparse,itertools,json,time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from scipy.special import expit
from common import *
from run_expanded import torch_model,predict_neural

def main(a):
    torch.set_num_threads(2)
    out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    config=json.loads(Path(a.config).read_text()); cs=sha(a.config)
    raw,z,mu,sd=load_data(a.handoff)
    q75,q90=np.quantile(z[:676,ILI],[.75,.90])
    rows=[];peaks=[];cost=[]
    for L in HORIZONS:
        vx,vy,vo=windows(z,L,'validation');tx,ty,to=windows(z,L,'test')
        for seed in SEEDS:
            t0=time.perf_counter();vpred=[];tpred=[]
            for name,width,where in [('NLinear',0,a.expanded),('TimesNet',16,a.timesnet)]:
                p=Path(where)/f'{name}_L{L}_s{seed}'
                model=torch_model(name,L,width)
                model.load_state_dict(torch.load(p/'selected_state.pt',map_location='cpu',weights_only=True))
                vpred.append(predict_neural(model,vx,'cpu'))
                d=np.load(p/'predictions.npz');np.testing.assert_allclose(d['target'],ty)
                tpred.append(d['pred'])
            candidate=[];tail=vy[:,:,ILI]>q90
            for b in itertools.product(config['b0'],config['b1'],config['b2']):
                b0,b1,b2=b
                w=expit(b0+b1*(vx[:,-1,ILI]-q75)+b2*(vx[:,-1,ILI]-vx[:,-5,ILI]))[:,None,None]
                v=w*vpred[0]+(1-w)*vpred[1]
                mse=float(((v-vy)**2).mean())
                tm=float(((v[:,:,ILI]-vy[:,:,ILI])[tail]**2).mean()) if tail.any() else 0.
                candidate.append(dict(b0=b0,b1=b1,b2=b2,val_mse=mse,val_tail_mse=tm,objective=mse+tm))
            best=min(candidate,key=lambda x:x['objective'])
            w=expit(best['b0']+best['b1']*(tx[:,-1,ILI]-q75)+best['b2']*(tx[:,-1,ILI]-tx[:,-5,ILI]))[:,None,None]
            pred=w*tpred[0]+(1-w)*tpred[1]
            np.savez_compressed(out/f'PeakBlend_L{L}_s{seed}.npz',pred=pred,target=ty,origins=to,weights=w)
            pd.DataFrame(candidate).to_csv(out/f'gate_validation_L{L}_s{seed}.csv',index=False)
            rows.append(dict(model='PeakBlend',L=L,seed=seed,track='EXPANDED_EXPLORATORY_966',uses_text=False,config_sha256=cs,
                **best,**score(pred,ty,sd)))
            peaks+=peak_events(to+1,ty[:,0,ILI]*sd[ILI]+mu[ILI],pred[:,0,ILI]*sd[ILI]+mu[ILI],'PeakBlend',L,seed)
            cost.append(dict(model='PeakBlend',L=L,seed=seed,additional_wall_seconds=time.perf_counter()-t0,
                gpu_hours=0,device='cpu',note='Additional validation-gate cost only; deployment requires both trained experts'))
    pd.DataFrame(rows).to_csv(out/'hybrid_cells.csv',index=False)
    pd.DataFrame(peaks).to_csv(out/'hybrid_peak_events.csv',index=False)
    pd.DataFrame(cost).to_csv(out/'hybrid_cost.csv',index=False)
    peak_summary(pd.DataFrame(peaks)).to_csv(out/'hybrid_peak_by_L.csv',index=False)
    print(pd.DataFrame(rows).groupby('L')[['mse_z_all7','mse_z_ili']].mean().to_string())

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ['handoff','expanded','timesnet','out','config']:p.add_argument('--'+name,required=True)
    main(p.parse_args())
