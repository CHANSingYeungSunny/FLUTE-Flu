"""Recompute all recoverable evidence without editing the frozen handoff."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from common import *

def main(root,out):
    root,out=Path(root),Path(out); out.mkdir(exist_ok=True,parents=True)
    raw,z,mu,sd=load_data(root)
    pd.DataFrame(dict(feature=FEATURES,packaged_mean=mu,packaged_std=sd,
        refit_mean=raw[:676].mean(0),refit_std=raw[:676].std(0))).to_csv(out/'scaler_verification.csv',index=False)
    pd.DataFrame([dict(L=L,**{s:len(origins(L,s)) for s in SPLITS}) for L in HORIZONS]).to_csv(out/'window_counts.csv',index=False)
    embeddings=[]
    for L in HORIZONS:
        p=root/f'02_author_repo/code/dataset/illness/text_emb/text_emb_label_0507_{L}.txt'
        a=np.loadtxt(p)
        embeddings.append(dict(L=L,rows=a.shape[0],dims=a.shape[1],sha256=sha(p),
            max_token_difference=float(abs(a-a[0]).max()),
            scope='static token matrix reused across origins; tokens NOT identical'))
    pd.DataFrame(embeddings).to_csv(out/'embedding_audit.csv',index=False)
    metrics=[]; leads=[]; events=[]; endpoint_events=[]; validation=[]
    for L in HORIZONS:
        o=origins(L,'test'); _,true,_=windows(z,L,'test')
        for seed in SEEDS:
            p=root/f'04_benchmark/miflu/miflu_strict966__L{L}__seed{seed}/test_predictions_miflu_strict966__L{L}__seed{seed}.csv'
            d=pd.read_csv(p)
            key=['forecast_origin','forecast_lead','feature_index']
            assert not d.duplicated(key).any()
            assert d.dataset_hash.eq(DATA_SHA).all() and d.seed.eq(seed).all()
            assert d.horizon.eq(L).all() and d.split.eq('test').all()
            assert d.target_start_row.eq(d.forecast_origin+1).all()
            assert d.target_end_row.eq(d.forecast_origin+L).all()
            assert (d.target_start_row.ge(773)&d.target_end_row.le(965)).all()
            d=d.sort_values(key)
            expected=pd.MultiIndex.from_product([o,range(1,L+1),range(7)]).to_frame(index=False).to_numpy()
            np.testing.assert_array_equal(d[key].to_numpy(),expected)
            assert d.corrected_feature_name.tolist()==[FEATURES[i] for i in expected[:,2]]
            pred=d.y_pred_z.to_numpy().reshape(len(o),L,7)
            target=d.y_true_z.to_numpy().reshape(len(o),L,7)
            maxerr=float(abs(target-true).max()); assert maxerr<3e-6
            metrics.append(dict(model='miflu',L=L,seed=seed,source=str(p.relative_to(root)),**score(pred,target,sd)))
            np.savez_compressed(out/f'legacy_miflu_L{L}_s{seed}.npz',pred=pred,target=target,origins=o)
            validation.append(dict(L=L,seed=seed,n_rows=len(d),max_target_z_error=maxerr,
                key_validation='PASS',source_sha256=sha(p)))
            for k in range(L):
                e=pred[:,k,:]-target[:,k,:]
                leads.append(dict(model='miflu',L=L,seed=seed,k=k+1,
                    mse_z_all7=float((e**2).mean()),mae_z_all7=float(abs(e).mean()),
                    mse_z_ili=float((e[:,ILI]**2).mean()),mae_z_ili=float(abs(e[:,ILI]).mean())))
            events += peak_events(o+1,target[:,0,ILI]*sd[ILI]+mu[ILI],
                        pred[:,0,ILI]*sd[ILI]+mu[ILI],'miflu',L,seed)
            # Compare actual terminal leads on identical target rows at every L.
            # Shared support across k=1 and k=L, all L: rows [832,942].
            for k,kind in [(1,'common_k1'),(L,'common_terminal')]:
                rows=o+k; keep=(rows>=832)&(rows<=942)
                endpoint_events += peak_events(rows[keep],target[keep,k-1,ILI]*sd[ILI]+mu[ILI],
                    pred[keep,k-1,ILI]*sd[ILI]+mu[ILI],'miflu',L,seed,kind)
    met=pd.DataFrame(metrics);met.to_csv(out/'verified_miflu_cells.csv',index=False)
    pd.DataFrame(validation).to_csv(out/'prediction_validation.csv',index=False)
    pd.DataFrame(leads).to_csv(out/'verified_miflu_actual_leads.csv',index=False)
    pd.DataFrame(events).to_csv(out/'verified_miflu_peak_events.csv',index=False)
    ep=pd.DataFrame(endpoint_events);ep.to_csv(out/'common_support_peak_events.csv',index=False)
    pd.concat([peak_summary(g).assign(metric=k) for k,g in ep.groupby('metric')]).to_csv(out/'common_support_peak_summary.csv',index=False)
    ranking=pd.read_csv(root/'08_paper_tables/TRACK_C_TEST_MSE_RANKING.csv')
    hor=pd.read_csv(root/'08_paper_tables/TRACK_C_PER_HORIZON_CHAMPIONS.csv')
    for L,g in met.groupby('L'):
        expected=hor[(hor.model=='miflu')&(hor.L==L)].iloc[0]
        np.testing.assert_allclose([g.mse_z_all7.mean(),g.mae_z_all7.mean()],[expected.mse,expected.mae],rtol=1e-8)
    b1=ranking[['model','mean_Test_MSE_4L','mean_Test_MAE_4L']].rename(columns={
        'mean_Test_MSE_4L':'MSE_z_all7','mean_Test_MAE_4L':'MAE_z_all7'})
    for name in ['MSE_z_ILITOTAL','MSE_counts2_ILITOTAL','MAE_z_ILITOTAL','MAE_counts_ILITOTAL']:
        b1[name]=np.nan
    b1.loc[b1.model=='miflu',['MSE_z_ILITOTAL','MSE_counts2_ILITOTAL','MAE_z_ILITOTAL','MAE_counts_ILITOTAL']]=met[['mse_z_ili','mse_counts2_ili','mae_z_ili','mae_counts_ili']].mean().to_numpy()
    b1['evidence']='aggregate CSV only; target-only errors unavailable'
    b1.loc[b1.model=='miflu','evidence']='raw predictions independently rescored'
    b1.to_csv(out/'B1_valid_physical_units.csv',index=False)
    # The arithmetic the prompt requests, labelled explicitly as an invalid-unit
    # diagnostic rather than misrepresented as physical MSE.
    arith=b1[['model','MSE_z_all7','MAE_z_all7']].copy()
    arith['MSE_z_all7_times_9003p15_squared']=arith.MSE_z_all7*9003.15**2
    arith['MAE_z_all7_times_9003p15']=arith.MAE_z_all7*9003.15
    arith['valid_patient_count_metric']=False
    arith.to_csv(out/'requested_arithmetic_NOT_patient_count_metrics.csv',index=False)
    wide=hor.pivot(index='model',columns='L',values='mse').reindex(ranking.model)
    wide['mean_4L']=wide[list(HORIZONS)].mean(axis=1)
    wide['best_L']=wide[list(HORIZONS)].idxmin(axis=1)
    wide['worst_L']=wide[list(HORIZONS)].idxmax(axis=1)
    wide['L60_vs_L24_pct']=100*(wide[60]/wide[24]-1)
    wide.to_csv(out/'B2_window_length_MSE.csv')
    prof=wide[list(HORIZONS)].div(wide.mean_4L,axis=0);prof.to_csv(out/'B2_normalized_profiles.csv')
    pd.DataFrame(hor).to_csv(out/'B2_per_horizon_MSE_MAE.csv',index=False)
    legacy_events=pd.read_csv(root/'04_benchmark/PTE_PIE_per_peak.csv')
    # Archive values are rounded to 2 decimals; statuses are frozen. Preserve
    # them; do not reclassify a threshold-near event from rounded values.
    pk=peak_summary(legacy_events); pk.to_csv(out/'B3_legacy_k1_per_model_L.csv',index=False)
    old=legacy_events[legacy_events.model=='miflu']
    assert (old.status=='Hit').sum()==sum(x['status']=='Hit' for x in events)==15
    peak_by_model=pd.DataFrame([dict(model=m,n_true=g.true_row.notna().sum(),
        n_hit=(g.status=='Hit').sum(),hit_rate_pct=100*(g.status=='Hit').sum()/g.true_row.notna().sum())
        for m,g in legacy_events.groupby('model')])
    peak_by_model.to_csv(out/'B3_legacy_peak_totals.csv',index=False)
    corr=ranking.merge(peak_by_model,on='model')
    rho,p=stats.spearmanr(corr.mean_Test_MSE_4L,corr.hit_rate_pct)
    # Paired SEED-LEVEL comparison, avoiding treating four horizons as n=12
    # independent observations. Exact sign-flip uses all eight assignments.
    per_seed=pd.read_csv(root/'08_paper_tables/TRACK_C_PER_SEED_RANKINGS.csv')
    a=per_seed.pivot(index='seed',columns='model',values='mean_mse')
    delta=(a.miflu-a.nlinear).to_numpy(); import itertools
    null=np.array([np.mean(delta*np.array(s)) for s in itertools.product([-1,1],repeat=3)])
    ps=float(np.mean(abs(null)>=abs(delta.mean())-1e-12))
    rc=pd.read_csv(root/'05_reproduction_audit/R1C_RESULTS_PER_CANDIDATE.csv')
    r=rc[rc.horizon.isin([str(x) for x in HORIZONS])].copy()
    r['horizon']=r.horizon.astype(int);r['seed']=r.seed.astype(int)
    r.to_csv(out/'R1C_existing_24_fits.csv',index=False)
    rp=r.groupby(['candidate_id','seed']).test_mse.mean().unstack(0)
    diff=rp.iloc[:,1]-rp.iloc[:,0]
    tt=stats.ttest_rel(rp.iloc[:,1],rp.iloc[:,0])
    se=stats.sem(diff); ci=stats.t.interval(.95,len(diff)-1,loc=diff.mean(),scale=se)
    r.groupby(['candidate_id','horizon'])[['test_mse','test_mae']].mean().reset_index().to_csv(out/'R1C_per_L_means.csv',index=False)
    summary=dict(verdict='PARTIAL_REPRODUCTION',unified_pair_key=UNIFIED_PAIR_KEY,
        dataset_sha256=DATA_SHA,official_report_sha256=sha(next((root/'04_benchmark').glob('*.docx'))),
        track_c_mse=float(met.mse_z_all7.mean()),paper_tableV_mean=1.4355,
        descriptive_cross_protocol_gap_pct=float(100*(met.mse_z_all7.mean()/1.4355-1)),
        five_percent_upper_bound=1.4355*1.05,
        miflu_nlinear_paired_seed_mean_difference=float(delta.mean()),
        miflu_nlinear_exact_signflip_p=ps,n_independent_seeds=3,
        mse_vs_peak_spearman_rho=float(rho),mse_vs_peak_spearman_p=float(p),
        r1c_C0_mean=float(rp.iloc[:,0].mean()),r1c_C1_mean=float(rp.iloc[:,1].mean()),
        r1c_paired_delta=float(diff.mean()),r1c_paired_t_p=float(tt.pvalue),
        r1c_paired_delta_95ci=list(ci),r1c_percent_gap_removed_within_R=100*float(-diff.mean())/(float(rp.iloc[:,0].mean())-1.4355),
        peak_consensus_31of36='NOT_VERIFIABLE: peak_criteria.json absent; supplied event CSVs show 15/36',
        hpc='BLOCKED: missing HPC_GUIDE, hostname DNS failure, no SSH keys in runtime',
        r1b_model='MISSING: required by the supplied R1C trainer; cannot exactly retrain Track C from this archive')
    (out/'audit_summary.json').write_text(json.dumps(summary,indent=2))
    # Snapshot every packaged input, so preservation is mechanically checkable.
    pd.DataFrame([dict(path=str(p.relative_to(root)),sha256=sha(p),bytes=p.stat().st_size)
                  for p in sorted(root.rglob('*')) if p.is_file()]).to_csv(out/'input_sha256_manifest.csv',index=False)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--handoff',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();main(a.handoff,a.out)
