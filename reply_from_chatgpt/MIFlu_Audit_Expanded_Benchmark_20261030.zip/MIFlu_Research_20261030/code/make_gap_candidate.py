"""Create a separate C2 trainer; requires missing r1b_model.py for execution.

Never edits an evidence file. No C2 result is fabricated or promoted to Track C.
"""
import argparse
from pathlib import Path
from common import sha

def main(a):
    src=Path(a.handoff)/'05_reproduction_audit/r1c_c1_train.py'
    text=src.read_text()
    old='''            e1 = ep + 1
            cur = a.lr if e1 < 3 else a.lr * (0.9 ** (e1 - 3))'''
    new='''            # Match the author's END-of-previous-epoch update exactly.
            # ep is zero-based: training epoch 4 still uses the epoch-3 update.
            e_previous = ep
            cur = a.lr if e_previous < 3 else a.lr * (0.9 ** (e_previous - 3))'''
    assert text.count(old)==1,'Upstream trainer changed; review before patching'
    text=text.replace(old,new)
    text=text.replace('r1c_c1__L','r1c_c2_endmatch__L').replace('C1_released_type1_scheduler','C2_end_of_epoch_matched_scheduler')
    text=text.replace('r1c_c1_train.py — R1-C candidate C1.','C2 schedule-alignment extension. NOT RUN. Original source SHA256: '+sha(src))
    text=text.replace('''        # C1: the released type1 schedule, applied at the START of 1-based epoch
        # (ep+1). Equivalent to the author calling
        # adjust_learning_rate(opt, epoch + 1) at the end of the previous epoch.''',
        '''        # C2: match the released END-of-epoch schedule at the start
        # of the NEXT epoch. This repairs the one-epoch shift in packaged C1.''')
    p=Path(a.out)
    if p.exists():raise SystemExit('Refusing to overwrite candidate')
    p.write_text(text)
    print('Created C2 candidate; NOT RUN. Requires the original missing r1b_model.py.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--handoff',required=True);p.add_argument('--out',required=True);main(p.parse_args())
