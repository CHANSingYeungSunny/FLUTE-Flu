"""Independent replay of every new saved prediction array and preservation check."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from common import *

def main(a):
    base=Path(a.output);r=base/'results';root=Path(a.handoff)
    raw,z,mu,sd=load_data(root);checks=[]
    for section in ['expanded','timesnet','autoformer']:
        d=pd.read_csv(r/section/'expanded_cells.csv')
        for row in d.itertuples():
            p=r/section/f'{row.model}_L{row.L}_s{row.seed}'
            q=np.load(p/'predictions.npz');_,truth,o=windows(z,row.L,'test')
            np.testing.assert_array_equal(o,q['origins']);np.testing.assert_array_equal(truth,q['target'])
            metric=score(q['pred'],q['target'],sd)
            for k,v in metric.items():np.testing.assert_allclose(v,getattr(row,k),rtol=1e-10)
            sel=json.loads((p/'selection.json').read_text())
            assert row.selected_candidate==min(range(len(sel)),key=lambda j:sel[j]['val_mse'])
            for s in sel:
                if s['curve']:
                    curve=s['curve'];best=min(curve,key=lambda c:c['val_mse'])
                    assert s['best_epoch']==best['epoch'];assert s['val_mse']==best['val_mse']
            checks.append(dict(section=section,model=row.model,L=row.L,seed=row.seed,scoring='PASS',keys='PASS',selection='PASS'))
    h=pd.read_csv(r/'hybrid/hybrid_cells.csv')
    for row in h.itertuples():
        p=r/'hybrid'/f'PeakBlend_L{row.L}_s{row.seed}.npz'
        q=np.load(p);_,truth,o=windows(z,row.L,'test')
        np.testing.assert_array_equal(o,q['origins']);np.testing.assert_array_equal(truth,q['target'])
        for k,v in score(q['pred'],q['target'],sd).items():np.testing.assert_allclose(v,getattr(row,k),rtol=1e-10)
        gate=pd.read_csv(r/'hybrid'/f'gate_validation_L{row.L}_s{row.seed}.csv')
        np.testing.assert_allclose(row.objective,gate.objective.min())
        checks.append(dict(section='hybrid',model=row.model,L=row.L,seed=row.seed,scoring='PASS',keys='PASS',selection='PASS'))
    manifest=pd.read_csv(r/'input_sha256_manifest.csv')
    for row in manifest.itertuples():assert sha(root/row.path)==row.sha256
    assert len(checks)==144
    pd.DataFrame(checks).to_csv(r/'independent_delivery_verification.csv',index=False)
    # Every stored code file must parse; this is not a claim that optional LLM
    # backends, missing MIFlu modules or unavailable hardware were executed.
    import ast
    for p in (base/'code').rglob('*.py'):ast.parse(p.read_text())
    summary=dict(new_cells_verified=len(checks),frozen_input_files_unchanged=len(manifest),
        official_dataset_sha256=DATA_SHA,status='PASS',
        llm_training_executed=False,MIFlu_retraining_executed=False)
    (r/'delivery_verification.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--handoff',required=True);p.add_argument('--output',required=True);main(p.parse_args())
