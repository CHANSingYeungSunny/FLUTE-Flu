"""Regression checks for scientific failure modes, using synthetic values."""
import unittest
import numpy as np
import pandas as pd
from common import origins,score,peak_events,peak_summary,pick_peaks

class ContractTests(unittest.TestCase):
    def test_strict_boundaries(self):
        expected={24:(549,74,170),36:(537,62,158),48:(525,50,146),60:(513,38,134)}
        for L,counts in expected.items():
            self.assertEqual(tuple(len(origins(L,s)) for s in ['train','validation','test']),counts)
            self.assertEqual(origins(L,'test')[0],772)
            self.assertEqual(origins(L,'test')[-1]+L,965)
    def test_affine_scaling_and_variable_scope(self):
        true=np.zeros((3,24,7));pred=true.copy();pred[:,:,0]=10;pred[:,:,4]=2
        sd=np.arange(1,8,dtype=float)
        r=score(pred,true,sd)
        self.assertEqual(r['mse_z_ili'],4)
        self.assertEqual(r['mse_counts2_ili'],100)
        self.assertEqual(r['mae_counts_ili'],10)
        self.assertNotEqual(r['mse_z_all7']*sd[4]**2,r['mse_counts2_ili'])
    def test_misses_stay_in_denominator(self):
        ev=pd.DataFrame([dict(model='a',L=24,true_row=1,PTE_wk=0,PIE_pct=0,status='Hit'),
                         dict(model='a',L=24,true_row=5,PTE_wk=np.nan,PIE_pct=np.nan,status='Missed')])
        s=peak_summary(ev).iloc[0]
        self.assertEqual(s.hit_rate_pct,50)
        self.assertEqual(s.n_missed,1)
        self.assertEqual(s.mean_combined,'PASS') # illustrates why mean PASS != all hits
    def test_invalid_shapes_and_nonfinite_rejected(self):
        with self.assertRaises(ValueError): score(np.zeros((2,7)),np.zeros((2,7)),np.ones(7))
        with self.assertRaises(ValueError): score(np.full((2,24,7),np.nan),np.zeros((2,24,7)),np.ones(7))
    def test_legacy_min_sep_defect_is_explicit(self):
        y=np.zeros(80);y[10]=10;y[35]=9
        self.assertEqual(pick_peaks(y,min_sep=40),[10,35])

if __name__=='__main__':unittest.main()
