"""Make a portable artifact with a per-file SHA256 manifest."""
import argparse,json,zipfile
from pathlib import Path
from common import sha

def main(a):
    root=Path(a.source).resolve();dest=Path(a.zip).resolve()
    assert not dest.is_relative_to(root),'Bundle must be outside source tree'
    files=[p for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='OUTPUT_SHA256_MANIFEST.json']
    manifest=[dict(path=str(p.relative_to(root)),sha256=sha(p),bytes=p.stat().st_size) for p in files]
    mp=root/'OUTPUT_SHA256_MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2));files.append(mp)
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,'MIFlu_Research_20261030/'+str(p.relative_to(root)))
    with zipfile.ZipFile(dest) as z:
        bad=z.testzip();assert bad is None,bad
    print(json.dumps(dict(file=str(dest),bytes=dest.stat().st_size,sha256=sha(dest),entries=len(files))))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--zip',required=True);main(p.parse_args())
