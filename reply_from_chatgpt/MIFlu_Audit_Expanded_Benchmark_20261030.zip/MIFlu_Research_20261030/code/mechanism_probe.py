"""Generic causal-attention positive/negative controls, not an MIFlu verdict.

Shows why static context is not necessarily useless, and why *suffix-only*
causal fusion cannot affect prefix outputs in the stated deterministic graph.
No pretrained model and no missing R1B implementation are substituted.
"""
import json
from pathlib import Path
import torch

def main(out):
    torch.manual_seed(8127)
    numeric=torch.randn(2,5,16,dtype=torch.float64)
    text=torch.randn(2,3,16,dtype=torch.float64,requires_grad=True)
    Wq,Wk,Wv=[torch.randn(16,16,dtype=torch.float64)/4 for _ in range(3)]
    def forward(t,placement):
        x=torch.cat([numeric,t],dim=1) if placement=='suffix' else torch.cat([t,numeric],dim=1)
        q,k,v=x@Wq,x@Wk,x@Wv
        scores=q@k.transpose(-1,-2)/4
        mask=torch.ones(x.shape[1],x.shape[1],dtype=torch.bool).triu(1)
        y=scores.masked_fill(mask,float('-inf')).softmax(-1)@v
        return y[:,:5] if placement=='suffix' else y[:,3:]
    result={}
    for placement in ['suffix','prefix']:
        y=forward(text,placement)
        grad=torch.autograd.grad(y.square().sum(),text,retain_graph=True)[0]
        delta=(y-forward(text+1.234,placement)).abs().max().item()
        result[placement]=dict(max_output_perturbation=delta,text_gradient_norm=grad.norm().item())
    assert result['suffix']['max_output_perturbation']==0
    assert result['suffix']['text_gradient_norm']==0
    assert result['prefix']['max_output_perturbation']>0
    result['interpretation']='PASS generic graph controls only. MIFlu GPU/CPU contradiction UNRESOLVED; missing R1B code and GPU prevent matched replay.'
    Path(out).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);main(p.parse_args().out)
