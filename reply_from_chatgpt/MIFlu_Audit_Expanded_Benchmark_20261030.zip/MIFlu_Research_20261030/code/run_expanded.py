"""Exploratory CPU benchmark, separate from frozen Track C.

No test-based tuning. Candidate set is fixed in protocol/config.json BEFORE
execution; validation selects configurations/checkpoints. The already exposed
test set makes this exploratory even though this script never tunes on test.
"""
from __future__ import annotations
import argparse, copy, json, os, platform, sys, time
from pathlib import Path
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
os.environ.setdefault('MKL_NUM_THREADS','2')
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.decomposition import PCA
from sklearn.multioutput import MultiOutputRegressor
from common import *

class TargetPCARegressor:
    """Train-only target PCA reduces 7L outputs to 8 latent responses.

    This is explicitly part of the estimator (also applied to SVR), not an
    implementation of unrestricted independent-output boosting/SVR.
    """
    def __init__(self, base): self.base=base
    def fit(self,x,y):
        self.pca=PCA(n_components=8,svd_solver='full')
        self.model=MultiOutputRegressor(self.base,n_jobs=1)
        self.model.fit(x,self.pca.fit_transform(y)); return self
    def predict(self,x): return self.pca.inverse_transform(self.model.predict(x))

def classical(name, cfg, seed):
    if name=='DecisionTree':return DecisionTreeRegressor(random_state=seed,**cfg)
    if name=='RandomForest':return RandomForestRegressor(random_state=seed,n_jobs=2,**cfg)
    if name=='PCA-HistGB':return TargetPCARegressor(HistGradientBoostingRegressor(random_state=seed,early_stopping=False,**cfg))
    if name=='PCA-SVR':return TargetPCARegressor(SVR(kernel='rbf',gamma='scale',**cfg))
    if name=='KNN':return KNeighborsRegressor(weights='distance',n_jobs=2,**cfg)
    raise KeyError(name)

def torch_model(name,L,width):
    import torch
    from torch import nn
    class Forecaster(nn.Module):
        def __init__(self):
            super().__init__()
            if name=='NLinear':self.core=nn.Linear(T,L)
            elif name=='DNN':self.core=nn.Sequential(nn.Flatten(),nn.Linear(T*N,width),nn.GELU(),nn.Linear(width,width),nn.GELU(),nn.Linear(width,L*N))
            elif name=='CNN':
                self.core=nn.Sequential(nn.Conv1d(N,width,5,padding=2),nn.GELU(),nn.Conv1d(width,width,5,padding=2),nn.GELU(),nn.AdaptiveAvgPool1d(13),nn.Flatten(),nn.Linear(13*width,L*N))
            elif name=='GRU':
                self.rnn=nn.GRU(N,width,batch_first=True);self.head=nn.Linear(width,L*N)
            elif name in ('TimesNet','Autoformer'):
                # Unmodified upstream architecture, compact disclosed capacity.
                # TimesNet is an FFT/2D-convolution model, not a transformer.
                import importlib.util
                from types import SimpleNamespace
                vendor=Path(__file__).parent/'vendor/tslib'
                sys.path.insert(0,str(vendor))
                spec=importlib.util.spec_from_file_location('upstream_'+name.lower(),vendor/f'models/{name}.py')
                mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
                cfg=SimpleNamespace(task_name='long_term_forecast',seq_len=T,label_len=18,pred_len=L,
                    e_layers=1,top_k=2,d_model=width,d_ff=width*2,num_kernels=2,enc_in=N,c_out=N,
                    embed='timeF',freq='h',dropout=.1)
                if name=='Autoformer':
                    cfg.dec_in=N;cfg.d_layers=1;cfg.moving_avg=25;cfg.factor=1
                    cfg.n_heads=2;cfg.activation='gelu'
                self.core=mod.Model(cfg)
        def forward(self,x):
            if name=='NLinear':
                last=x[:,-1:,:].detach()
                return self.core((x-last).transpose(1,2)).transpose(1,2)+last
            if name=='TimesNet':return self.core(x,None,None,None)
            if name=='Autoformer':
                dec=torch.cat([x[:,-18:,:],torch.zeros(x.shape[0],L,N,device=x.device)],1)
                return self.core(x,None,dec,None)
            mean=x.mean(1,keepdim=True).detach()
            sd=(x.var(1,keepdim=True,unbiased=False)+1e-5).sqrt().detach()
            a=(x-mean)/sd
            if name=='GRU':
                h,_=self.rnn(a);y=self.head(h[:,-1])
            else:y=self.core(a.transpose(1,2) if name=='CNN' else a)
            return y.reshape(-1,L,N)*sd+mean
    return Forecaster()

def fit_neural(name,L,seed,cfg,data,epochs,device):
    import torch
    from torch import nn
    torch.set_num_threads(2);torch.manual_seed(seed);np.random.seed(seed)
    torch.use_deterministic_algorithms(True)
    model=torch_model(name,L,cfg['width']).to(device)
    opt=torch.optim.Adam(model.parameters(),lr=cfg['lr'])
    x,y,_=data['train'];vx,vy,_=data['validation']
    x=torch.from_numpy(x);y=torch.from_numpy(y)
    vx=torch.from_numpy(vx).to(device);vy=torch.from_numpy(vy).to(device)
    gen=torch.Generator().manual_seed(seed)
    loader=torch.utils.data.DataLoader(torch.utils.data.TensorDataset(x,y),batch_size=16,shuffle=True,generator=gen)
    best=float('inf');state=None;epoch=None;curve=[]
    for ep in range(epochs):
        model.train();total=0
        for xb,yb in loader:
            xb,yb=xb.to(device),yb.to(device)
            opt.zero_grad();loss=nn.functional.mse_loss(model(xb),yb)
            loss.backward();opt.step();total+=loss.item()*len(xb)
        model.eval()
        with torch.no_grad():v=float(nn.functional.mse_loss(model(vx),vy))
        curve.append(dict(epoch=ep+1,train_mse=total/len(x),val_mse=v))
        if v<best:
            best=v;epoch=ep+1;state={k:t.detach().cpu().clone() for k,t in model.state_dict().items()}
    model.load_state_dict(state)
    return model,best,epoch,curve

def predict_neural(model,x,device):
    import torch
    model.eval();pred=[]
    with torch.no_grad():
        for xb in np.array_split(x,max(1,int(np.ceil(len(x)/32)))):
            pred.append(model(torch.from_numpy(xb).to(device)).cpu().numpy())
    return np.concatenate(pred)

def main(a):
    root,out=Path(a.handoff),Path(a.out);out.mkdir(parents=True,exist_ok=True)
    cfgpath=Path(a.config);config=json.loads(cfgpath.read_text())
    cfgsha=sha(cfgpath)
    raw,z,mu,sd=load_data(root)
    result=[];ev=[];cost=[];selection=[]
    requested=a.models.split(',') if a.models else list(config['classical'])+list(config['neural'])
    for name in requested:
        for L in HORIZONS:
            data={s:windows(z,L,s) for s in SPLITS}
            for seed in config['seeds']:
                cell=out/f'{name}_L{L}_s{seed}';cell.mkdir(exist_ok=True)
                mp=cell/'metrics.json'
                if mp.exists():
                    saved=json.loads(mp.read_text());assert saved['config_sha256']==cfgsha
                    result.append(saved);ev+=json.loads((cell/'peak_events.json').read_text())
                    cost.append(json.loads((cell/'cost.json').read_text()));continue
                start=time.perf_counter();candidate_log=[];best=None
                is_neural=name in config['neural']
                candidates=config['neural'][name] if is_neural else config['classical'][name]
                for j,cfg in enumerate(candidates):
                    cstart=time.perf_counter()
                    if is_neural:
                        model,v,epoch,curve=fit_neural(name,L,seed,cfg,data,config['epochs'],a.device)
                    else:
                        x,y,_=data['train'];vx,vy,_=data['validation']
                        model=classical(name,cfg,seed).fit(x.reshape(len(x),-1),y.reshape(len(y),-1))
                        vp=model.predict(vx.reshape(len(vx),-1)).reshape(vy.shape)
                        v=float(((vp-vy)**2).mean());epoch=None;curve=[]
                    candidate_log.append(dict(candidate=j,config=cfg,val_mse=v,best_epoch=epoch,seconds=time.perf_counter()-cstart,curve=curve))
                    if best is None or v<best[0]:best=(v,j,model,epoch)
                train_seconds=time.perf_counter()-start
                val,j,model,epoch=best
                # Only the frozen validation winner sees test, once per cell.
                tx,ty,o=data['test'];t0=time.perf_counter()
                pred=predict_neural(model,tx,a.device) if is_neural else model.predict(tx.reshape(len(tx),-1)).reshape(ty.shape)
                infer=time.perf_counter()-t0
                row=dict(track='EXPANDED_EXPLORATORY_966',model=name,L=L,seed=seed,
                    config_sha256=cfgsha,dataset_sha256=DATA_SHA,reference_pair_anchor=UNIFIED_PAIR_KEY,
                    cell_pair_key=f'966|L{L}|seed{seed}',val_mse=val,selected_candidate=j,best_epoch=epoch,
                    uses_text=False,**score(pred,ty,sd))
                # Retain predictions and targets, including all leads and all variables.
                np.savez_compressed(cell/'predictions.npz',pred=pred,target=ty,origins=o)
                per=[]
                for k in range(L):
                    per.append(dict(k=k+1,**score(pred[:,k:k+1],ty[:,k:k+1],sd)))
                pd.DataFrame(per).to_csv(cell/'per_lead_metrics.csv',index=False)
                if is_neural:
                    import torch
                    torch.save(model.state_dict(),cell/'selected_state.pt')
                    params=sum(p.numel() for p in model.parameters())
                else:params=None
                # Count-based estimators do not have a meaningful NN parameter count.
                cr=dict(model=name,L=L,seed=seed,fit_and_val_seconds=train_seconds,
                    test_inference_seconds=infer,test_ms_per_origin=1000*infer/len(tx),
                    device=a.device if is_neural else 'cpu',gpu_hours=0.0 if a.device=='cpu' else (train_seconds+infer)/3600,
                    cpu_wall_hours=(train_seconds+infer)/3600 if a.device=='cpu' else None,
                    parameters=params,flops=None,uses_text=False,
                    cost_scope='includes all validation candidates; excludes environment setup; FLOPs unmeasured')
                pk=peak_events(o+1,ty[:,0,ILI]*sd[ILI]+mu[ILI],pred[:,0,ILI]*sd[ILI]+mu[ILI],name,L,seed)
                for p,value in [('metrics.json',row),('cost.json',cr),('selection.json',candidate_log),('peak_events.json',pk)]:
                    (cell/p).write_text(json.dumps(value,indent=2))
                result.append(row);cost.append(cr);ev+=pk
                print(f'{name} L={L} seed={seed}: val={val:.4f} test(all7)={row["mse_z_all7"]:.4f} ILI={row["mse_z_ili"]:.4f}; {train_seconds:.1f}s',flush=True)
                # Persist incrementally after every complete cell.
                pd.DataFrame(result).to_csv(out/'expanded_cells.csv',index=False)
                pd.DataFrame(cost).to_csv(out/'expanded_cost_cells.csv',index=False)
                pd.DataFrame(ev).to_csv(out/'expanded_peak_events.csv',index=False)
    pd.DataFrame(result).to_csv(out/'expanded_cells.csv',index=False)
    pd.DataFrame(cost).to_csv(out/'expanded_cost_cells.csv',index=False)
    pd.DataFrame(ev).to_csv(out/'expanded_peak_events.csv',index=False)
    peak_summary(pd.DataFrame(ev)).to_csv(out/'expanded_peak_by_L.csv',index=False)
    import importlib.metadata as md
    (out/'environment.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform(),
        dependencies={x:md.version(x) for x in ['numpy','pandas','scipy','scikit-learn','torch','matplotlib']},
        device=a.device,config_sha256=cfgsha,all_results_exploratory=True),indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--handoff',required=True);p.add_argument('--out',required=True)
    p.add_argument('--config',required=True);p.add_argument('--device',default='cpu');p.add_argument('--models',default='')
    main(p.parse_args())
