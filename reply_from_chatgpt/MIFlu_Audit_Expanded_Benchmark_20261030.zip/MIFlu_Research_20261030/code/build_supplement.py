"""Build Markdown tables, scientific figures and a single audit supplement.

The historical authoritative DOCX/MD remain byte-identical. This supplement
does not appoint a replacement champion or constitute a submission-ready paper.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import *

def savefig(fig,p):
    fig.savefig(p.with_suffix('.png'),dpi=200,bbox_inches='tight')
    fig.savefig(p.with_suffix('.pdf'),bbox_inches='tight');plt.close(fig)

def main(a):
    base=Path(a.output);r=base/'results';figdir=base/'figures';figdir.mkdir(exist_ok=True)
    audit=json.loads((r/'audit_summary.json').read_text())
    groups=[pd.read_csv(r/x/'expanded_cells.csv') for x in ['expanded','timesnet','autoformer']]
    d=pd.concat(groups,ignore_index=True)
    assert len(d)==132 and not d.duplicated(['model','L','seed']).any()
    assert d.groupby('model').size().eq(12).all()
    hy=pd.read_csv(r/'hybrid/hybrid_cells.csv');assert len(hy)==12
    full=pd.concat([d,hy],ignore_index=True)
    full.to_csv(r/'expanded_all_cells.csv',index=False)
    metrics=['mse_z_all7','mae_z_all7','mse_z_ili','mae_z_ili','mse_counts2_ili','mae_counts_ili']
    byL=full.groupby(['model','L'])[metrics].mean().reset_index()
    byL.to_csv(r/'expanded_all_per_L.csv',index=False)
    means=full.groupby(['model','seed'])[metrics].mean().reset_index()
    summary=means.groupby('model')[metrics].mean()
    summary['sd_seed_MSE_all7']=means.groupby('model').mse_z_all7.std(ddof=1)
    summary=summary.sort_values('mse_z_all7');summary.to_csv(r/'expanded_summary.csv')
    wide=byL.pivot(index='model',columns='L',values='mse_z_all7').reindex(summary.index)
    wide['mean_4L']=wide[list(HORIZONS)].mean(1)
    wide['best_L']=wide[list(HORIZONS)].idxmin(1);wide['worst_L']=wide[list(HORIZONS)].idxmax(1)
    wide.to_csv(r/'expanded_MSE_profiles.csv')
    prof=wide[list(HORIZONS)].div(wide.mean_4L,axis=0);prof.to_csv(r/'expanded_normalized_profiles.csv')
    ep=pd.concat([pd.read_csv(r/x/'expanded_peak_events.csv') for x in ['expanded','timesnet','autoformer']]+[pd.read_csv(r/'hybrid/hybrid_peak_events.csv')],ignore_index=True)
    ps=peak_summary(ep);ps.to_csv(r/'expanded_all_peak_by_L.csv',index=False)
    ep.to_csv(r/'expanded_all_peak_events.csv',index=False)
    peak_tot=[]
    for m,g in ep.groupby('model'):
        g=g[g.true_row.notna()];mt=g[g.PTE_wk.notna()]
        peak_tot.append(dict(model=m,n_true=len(g),n_hit=int((g.status=='Hit').sum()),
            hit_rate_pct=100*(g.status=='Hit').mean(),matched_mean_PTE=mt.PTE_wk.mean(),matched_mean_PIE=mt.PIE_pct.mean()))
    peak_tot=pd.DataFrame(peak_tot).set_index('model').reindex(summary.index)
    peak_tot.to_csv(r/'expanded_peak_totals.csv')
    terminal_events=[];terminal_scores=[]
    _,_,physical_mu,physical_sd=load_data(a.handoff)
    for row in full.itertuples():
        if row.model=='PeakBlend':
            path=r/'hybrid'/f'PeakBlend_L{row.L}_s{row.seed}.npz'
        else:
            section='timesnet' if row.model=='TimesNet' else 'autoformer' if row.model=='Autoformer' else 'expanded'
            path=r/section/f'{row.model}_L{row.L}_s{row.seed}'/'predictions.npz'
        q=np.load(path);pred,target,org=q['pred'],q['target'],q['origins']
        k=row.L;tr=org+k;keep=(tr>=832)&(tr<=942)
        terminal_events+=peak_events(tr[keep],target[keep,k-1,ILI]*physical_sd[ILI]+physical_mu[ILI],
            pred[keep,k-1,ILI]*physical_sd[ILI]+physical_mu[ILI],row.model,row.L,row.seed,'common_terminal')
        terminal_scores.append(dict(model=row.model,L=row.L,seed=row.seed,k=k,
            **score(pred[:,k-1:k],target[:,k-1:k],physical_sd)))
    terminal_summary=peak_summary(pd.DataFrame(terminal_events))
    terminal_summary.to_csv(r/'expanded_actual_terminal_peak_by_L.csv',index=False)
    pd.DataFrame(terminal_events).to_csv(r/'expanded_actual_terminal_peak_events.csv',index=False)
    pd.DataFrame(terminal_scores).to_csv(r/'expanded_actual_terminal_scores.csv',index=False)
    costs=pd.concat([pd.read_csv(r/x/'expanded_cost_cells.csv') for x in ['expanded','timesnet','autoformer']],ignore_index=True)
    c=costs.groupby('model').agg(fit_val_seconds_mean=('fit_and_val_seconds','mean'),fit_val_seconds_total=('fit_and_val_seconds','sum'),
        inference_ms_per_origin=('test_ms_per_origin','mean'),gpu_hours_total=('gpu_hours','sum'),
        parameters_min=('parameters','min'),parameters_max=('parameters','max'))
    c['FLOPs']='unmeasured';c['uses_text']=False;c.to_csv(r/'expanded_cost_summary.csv')
    old=pd.read_csv(r/'B2_window_length_MSE.csv')
    oldprof=pd.read_csv(r/'B2_normalized_profiles.csv')
    b1=pd.read_csv(r/'B1_valid_physical_units.csv')
    pks=pd.read_csv(r/'B3_legacy_k1_per_model_L.csv')
    ar=pd.read_csv(r/'requested_arithmetic_NOT_patient_count_metrics.csv')
    # Figure 1: window-length scores, explicitly not terminal-lead scores.
    names=summary.index.tolist();xx=np.arange(len(names));w=.19
    fig,ax=plt.subplots(figsize=(14,5))
    colors=['#275D87','#34A0A4','#F0B35D','#D45D48']
    for j,L in enumerate(HORIZONS):ax.bar(xx+(j-1.5)*w,wide[L],w,label=f'L={L}',color=colors[j])
    ax.set_xticks(xx,names,rotation=30,ha='right');ax.set_ylabel('All-7-variable z-space MSE')
    ax.set_title('Exploratory CPU benchmark: mean over leads 1..L, 3 seeds')
    ax.legend(ncol=4,frameon=False);ax.grid(axis='y',alpha=.2);savefig(fig,figdir/'per_window_MSE')
    # Figure 2: legacy matched-only means, with a warning about survivor bias.
    fig,ax=plt.subplots(figsize=(11,6));ax.axvspan(0,1,color='#46a289',alpha=.10);ax.axhspan(0,25,color='#46a289',alpha=.10)
    for i,(m,row) in enumerate(peak_tot.iterrows()):
        if pd.notna(row.matched_mean_PTE):
            ax.scatter(row.matched_mean_PTE,row.matched_mean_PIE,s=40+row.hit_rate_pct*2,color=plt.cm.tab20(i/len(peak_tot)))
            ax.annotate(m,(row.matched_mean_PTE,row.matched_mean_PIE),xytext=(5,5+(i%2)*5),textcoords='offset points',fontsize=8)
    ax.axvline(1,ls='--',c='gray');ax.axhline(25,ls='--',c='gray')
    ax.set(xlabel='Mean PTE, matched peaks only (weeks)',ylabel='Mean PIE, matched peaks only (%)',
           title='One-week-ahead peak diagnostic: means do not determine event hits')
    fig.text(.5,-.02,'Marker size reflects event hit rate; means exclude misses. PCA-SVR has no matched peaks and is omitted.\nThese are one-week-ahead retrospective diagnostics, not clinical validation.',ha='center',fontsize=9)
    ax.set_xlim(0,2.2);ax.set_ylim(0,85)
    ax.grid(alpha=.2);savefig(fig,figdir/'peak_scatter')
    # Figure 3: CPU wall-time Pareto; exclude hybrid partial costs and GPU history.
    pareto=c.join(summary[['mse_z_all7']]);front=[]
    for name,row in pareto.sort_values('fit_val_seconds_mean').iterrows():
        if not front or row.mse_z_all7 < front[-1][2]:front.append((name,row.fit_val_seconds_mean,row.mse_z_all7))
    fig,ax=plt.subplots(figsize=(11,5))
    ax.scatter(pareto.fit_val_seconds_mean,pareto.mse_z_all7,s=55,c='#275D87')
    for i,(name,row) in enumerate(pareto.iterrows()):ax.annotate(name,(row.fit_val_seconds_mean,row.mse_z_all7),xytext=(5,5+(i%2)*4),textcoords='offset points',fontsize=8)
    ax.plot([v[1] for v in front],[v[2] for v in front],'--',c='#D45D48',label='Nondominated CPU configurations')
    ax.set_xscale('log');ax.set(xlabel='Mean fit + validation wall seconds per cell (log scale)',ylabel='All-7-variable z-space MSE',
        title='Measured CPU cost vs error; concurrent shared-host timings are approximate')
    ax.grid(alpha=.2);ax.legend(frameon=False);savefig(fig,figdir/'cost_accuracy_pareto')
    # Figure 4: actual leads in MIFlu, rather than confusing L with k.
    actual=pd.read_csv(r/'verified_miflu_actual_leads.csv').groupby(['L','k']).mse_z_all7.mean().reset_index()
    actual.to_csv(r/'miflu_actual_lead_means.csv',index=False)
    fig,ax=plt.subplots(figsize=(9,4))
    for L,g in actual.groupby('L'):ax.plot(g.k,g.mse_z_all7,label=f'Output window L={L}')
    ax.set(xlabel='Actual forecast lead k (weeks)',ylabel='All-7-variable z-space MSE',title='Archived MIFlu: distinct window lengths and actual leads')
    ax.grid(alpha=.2);ax.legend(frameon=False);savefig(fig,figdir/'miflu_actual_leads')
    # Full Markdown numeric tables, each mirrored as a CSV.
    def t(df):return table(df,formats={c:'.2f' for c in df.columns if 'pct' in str(c).lower() or 'PIE' in str(c)})
    raw,zz,mu,sd=load_data(a.handoff)
    rc=pd.read_csv(r/'R1C_per_L_means.csv')
    epcommon=pd.read_csv(r/'common_support_peak_summary.csv')
    timings=pd.read_csv(r/'scheduler_timeline.csv')
    llm=pd.read_csv(r/'llm_execution_status.csv').drop(columns=['MSE','MAE','PTE','PIE','measured_gpu_hours'])
    completion=pd.DataFrame([
        ('A1','COMPLETED locally','Data, splits, scorer, source/audit contradictions checked'),
        ('A2','PARTLY BLOCKED','Existing 24-fit R1C recomputed; C2 schedule candidate prepared, not trained'),
        ('A3','COMPLETED assessment','No causal percent allocation or achievable optimum is identifiable'),
        ('B1','COMPLETED where identifiable','Target-only MIFlu rescored; other seven target metrics unavailable'),
        ('B2','COMPLETED','All archived models: per-L scores and normalized profiles; MIFlu actual k also computed'),
        ('B3','COMPLETED with evidence conflict','32 archive model-by-L rows; consensus 31/36 cannot be verified'),
        ('B4','PARTLY COMPLETED','132 new CPU cells for 11 models + 12 hybrid evaluations; LLM arms not run'),
        ('B5','PRELIMINARY','Academic analysis and confirmatory protocol; publication claims await validation')],columns=['Part','Status','Evidence / limitation'])
    (base/'TABLES.md').write_text('# Generated numeric tables\n\n'+
        '\n\n'.join('## '+name+'\n\n'+t(df) for name,df in [
        ('B1 archived scores and valid target units',b1),('B2 archived window scores',old),
        ('B2 normalized archived profiles',oldprof),('B3 archived k=1 peak diagnostics',pks),
        ('New expanded per-L scores',byL),('New expanded means',summary.reset_index()),
        ('New expanded best and worst windows',wide.reset_index()),
        ('New expanded normalized profiles',prof.reset_index()),('New expanded per-L peak diagnostics',ps),
        ('New actual terminal-lead peak diagnostics',terminal_summary),
        ('New expanded cost summary',c.reset_index())]),encoding='utf-8')
    miflu_ili=b1[b1.model=='miflu'].iloc[0]
    msebest=summary.index[0];new_best=summary.iloc[0].mse_z_all7
    hybrid_vs_nlinear=100*(summary.loc['PeakBlend','mse_z_all7']/summary.loc['NLinear','mse_z_all7']-1)
    report=f'''# MIFlu research audit and exploratory benchmark supplement

Date: 30 October 2026 (Hong Kong). Status: **PARTIAL_REPRODUCTION**.

This is an evidence supplement to the single historical authoritative report, **not a replacement final report or a submission-ready manuscript**. The original DOCX and its MD mirror are unchanged. This supplement records newly verified facts, contradictions, and separately labelled exploratory experiments. It does not promote a new Track C champion. `UNIFIED_PAIR_KEY=966|L24|seed42` is retained as the supplied reference anchor; each other cell has its own real horizon/seed key. It is not a license to relabel every cell L24/seed42.

## Abstract

We audited the supplied MIFlu handoff, independently rescored all 12 packaged MIFlu test prediction files, and ran 132 new CPU model cells plus 12 exploratory hybrid evaluations on the unmodified author-966 dataset. The archived Track C mean seven-variable z-space MSE is {audit['track_c_mse']:.4f}; the paper Table V mean is 1.4355. Their descriptive separation is {audit['descriptive_cross_protocol_gap_pct']:.2f}%, **not an experimentally identified performance deficit under an identical protocol**. The data are US CDC National-Illness, not Hong Kong surveillance. A scalar ILITOTAL variance cannot denormalize the seven-variable aggregate. MIFlu's independently recomputed ILITOTAL-only mean MSE is {miflu_ili.MSE_z_ILITOTAL:.4f} z², equivalent to {miflu_ili.MSE_counts2_ILITOTAL:.4f} patient-count². Existing peak tables use actual lead k=1, not lead L. The packaged event evidence yields 15/36 MIFlu hits, while the user-specified 31/36 CONSENSUS cannot be authenticated because `peak_criteria.json` is missing. A prior scheduler sensitivity experiment changed 1.8561 to 1.8225 in separate Track R; a newly detected one-epoch schedule shift remains untested. The newly executed compact CPU suite includes classical, neural, TimesNet and Autoformer models with NLinear as its only learned linear baseline. All new results are exploratory because the test data were already exposed. New LLM feature/reasoning experiments and exact MIFlu retraining remain blocked by missing weights/code and inaccessible HPC.

## Introduction

The scientific question is whether language-derived context improves influenza forecasts beyond inexpensive numerical predictors, particularly at decision-relevant peaks. A lower aggregate MSE is not equivalent to better timing or intensity at epidemic peaks. Reproducing a reported table, comparing methods on a controlled test contract, establishing a text mechanism, and demonstrating operational utility are distinct research questions.

The correct target-paper title is *MIFlu: Large Language Model-Based Multimodal Influenza Forecasting Scheme*, by Moon, Shim, Kim and Hwang, IEEE JBHI 29(10), 7790–7801, DOI [10.1109/JBHI.2025.3561214](https://doi.org/10.1109/JBHI.2025.3561214). The alternative Hong Kong title in the prompt is not the title of that DOI. The supplied paper's Section V-A explicitly identifies US national and US regional data. Current publication metadata was checked against [the authors' institutional record](https://pure.korea.ac.kr/en/publications/miflu-large-language-model-based-multimodal-influenza-forecasting/).

Execution status:

{t(completion)}

## Related Work

MIFlu uses a frozen GPT-2 text embedder and a truncated forecasting GPT-2, with trainable patch/output projections, positional and layer-normalization parameters, and low-rank attention adapters. The released source implements token concatenation; it is not a cross-attention fusion implementation. The supplied paper compares national baselines largely using values cited from earlier studies, so Table V is not evidence of all methods being retrained under this project's Track C contract.

Kramer and Shaman (2019), [DOI 10.1371/journal.pcbi.1006742](https://doi.org/10.1371/journal.pcbi.1006742), evaluate peak timing within one week and peak intensity within 25% of the observed value. **The joint AND rule is this project's composite application of those two tolerances**; do not imply that the original article establishes this project's greedy peak picker or joint hit rate. The article analyzes forecasts by predicted lead to the epidemic peak, which differs from a model's output-window length.

Our new Autoformer and TimesNet implementations are unmodified model sources from the authors' [Time-Series-Library](https://github.com/thuml/Time-Series-Library), pinned to commit `4e938a1767106324dd753b2a44832bf870a0252e`. TimesNet is an FFT-driven 2D convolution model, not a transformer. Autoformer supplies the requested additional transformer family. Compact capacities, data protocol and training wrapper are disclosed below; these are not claims to replicate either method's original best published score.

## Methods

### Evidence hierarchy and frozen records

The archive contains 161 Python source files, all syntactically parsed in `results/source_inventory.json`. Source/audit checks focused on the author loader, model, trainer, embedder notebook, Track C master/scaler/peak contracts, R1-C trainer/results, canonical scorer and model-fidelity classes. Hashes for every input file appear in `results/input_sha256_manifest.csv`; no input was modified.

Conflicting statements are kept visible. For example, START_HERE says 36/36, the authoritative MD and event tables show 15/36, and the prompt asserts an unavailable 31/36 consensus. The authoritative MD also calls MIFlu a non-LLM model in several passages despite its own table and the model's GPT-2 backbone. These are documented report defects; they are not reasons to overwrite frozen evidence silently. New conclusions must be incorporated by a controlled future revision of the original authoritative DOCX/MD pair and its manifests.

### Dataset, scaling and split verification

Official SHA256: `{DATA_SHA}`. Independently verified shape: 966 rows by seven finite numerical features, excluding the synthetic date index. The project-schema 966-row copy is a separate byte representation; the 1025-row vintage is excluded from every calculation in this supplement.

Train is [0,676), validation [676,773), test [773,966), matching the released loader's integer 70:10:20 arithmetic. The paper supplies the ratio, not a dataset hash or exact integer boundaries, so exact identity to the unpublished training-time artifact cannot be proved from the paper alone. The packaged data and author CSV bytes match the declared hash. The author date column is a synthetic weekly index: do not equate its apparent 2016–2020 dates with verified CDC surveillance weeks or make calendar-specific COVID claims without an independent mapping.

For every origin o, input is [o−103,o] and target is [o+1,o+L]. All target rows must belong to the selected split. Counts, independently recomputed:

{t(pd.read_csv(r/'window_counts.csv'))}

The persisted scaler is train-only and agrees with a float64 refit to relative tolerance 2e−7. Small float32 rounding differences are documented, not silently refitted away. ILITOTAL mean is {mu[ILI]:.9f}, scale {sd[ILI]:.9f}. The prompt's 9003.15 is rounded. All valid physical calculations below use the packaged full-precision scale. No nonnegative clipping is introduced, because it would alter scores and break simple affine error conversion.

### Model fidelity and training audit (A1)

| Component | Verified evidence | Assessment |
| --- | --- | --- |
| T=104, K=6, patch=24, stride=2 | Author source + R1C configuration | Matched declarations; 42 patches per variable |
| LoRA r=4 | Author `GPT4TS_lora.py` + R1C config | Matched rank; released `c_attn` targets fused Q/K/V, not only Q/K as the paper diagram suggests |
| 20 epochs, batch=16, lr=0.0005 | Paper Table IV; R1C trainer | Matched settings; earlier audits claiming no paper provenance are stale |
| Optimizer / loss | Author main trainer; R1C trainer | Adam / MSE, no warmup found; optimizer is recovered from code, not unspecified everywhere |
| Scheduler | Author main + tools; R1C trainer | Author default end-of-epoch type1 decay; R1C start-of-epoch shift found; no exact corrected result available |
| Selection | Author main trainer selects on test each epoch | Track C deliberately repairs this with validation-only checkpoint selection; never reintroduce test selection to chase 1.4355 |
| Evaluation scope | Author Dataset_Custom length excludes feature multiplier on test | Test returns feature 0 only under released indexing; corrected Track C evaluates all seven. Major protocol mismatch, effect not quantified |
| Repetitions | Paper 10; Track C 3 | Seeds 42/43/44 versus unspecified paper repetition sequence; more runs cannot be assumed to shift the mean toward the target |
| Seed implementation | Author main initializes seed 2021 once before iteration loop | A seed exists; a per-repetition reseeding list does not. Audit language saying no seed call at all is inaccurate |
| Actual corrected Track C model | R1C imports `r1b_model.R1BCorrectedMIFlu` | **Module absent**. `miflu_model.py` is a different reconstruction; the supplied adapter is not evidence that it generated the Track C results |
| Frozen text assets | Four author text matrices included | 317×768 each; static across samples, but NOT identical vectors across tokens. Training-time original embedding hashes/weights not independently supplied |

The author model concatenates `[time_patches, text_tokens]` and retains the time-prefix outputs. Under ordinary deterministic causal attention, later suffix tokens cannot affect retained prefix positions. The paper's figure description instead uses the last patch positions, and its prose/slicing is internally ambiguous. **This is an architectural concern, not a resolution of the recorded GPU/CPU contradiction.** The missing corrected source and matched checkpoints prevent verification of what Track C actually executed.

The generic control in `mechanism_probe.py` numerically verifies suffix independence and a prefix positive control; it does not load pretrained GPT-2 or reproduce the contested GPU trace. Static text can still influence predictions when it is causally accessible, for example as a prefix, or through explicit cross-attention/FiLM; constancy over forecast origins alone does not establish uselessness.

Text asset fingerprints and token variation:

{t(pd.read_csv(r/'embedding_audit.csv'))}

### Scoring scope and physical units (B1)

For variable j, MSE_physical,j = MSE_z,j × scale_j² and MAE_physical,j = MAE_z,j × scale_j. MSE is measured in **patient-count²**, MAE and RMSE in patient counts. For seven heterogeneous variables, mean_j(MSE_z,j) × scale_ILITOTAL² is not the ILITOTAL MSE and has no defensible common physical unit. The true target-specific quantity must first be extracted from feature index 4. Means cancel from error conversion, but are essential when converting absolute values for PIE.

Seven non-MIFlu raw prediction sets are missing (`test_eval_download.tar.gz` and corresponding NPZs are not packaged). Thus their valid ILITOTAL errors are **NA**, not zero and not inferred from aggregate errors. The requested scalar multiplication is saved separately in `requested_arithmetic_NOT_patient_count_metrics.csv` only as explicitly invalid-unit arithmetic; it must not be cited as physical performance.

### Window length, actual lead and peak protocol (B2–B3)

L identifies an entire output window and its separately trained model. A per-L MSE averages all leads k=1…L, origins and variables. Changing L also changes the valid origin count, so an improving normalized per-L profile is not evidence of decreasing error as actual forecast lead grows. We additionally compute MIFlu errors for each actual k.

Legacy peak analysis takes feature 4, **k=1 only**, converts to counts, then picks peaks above each series' own mean and matches within ±2 weeks. The parameter called MIN_SEP_WEEKS=40 actually masks ±20 weeks, enforcing only 21-position spacing; it does not implement 40-week minimum separation. This frozen defect is reproduced for traceability, not endorsed. Means of PTE/PIE condition on matched peaks and censor larger timing failures, causing survivor bias. A PASS based on means is only a diagnostic; the valid event-level hit requires both tolerances, with missed true peaks in the denominator. False peaks are reported separately. The original three peaks repeated across L and seeds are not 36 independent epidemics.

B3 tables pool event errors rather than averaging rounded cell means. Archived event PIE is rounded to two decimals; frozen Hit statuses are preserved to avoid threshold reclassification errors. Newly recomputed MIFlu events use raw predictions. Additional shared-support analysis uses target rows 832–942 at k=1 and k=L for every L, avoiding unequal support. It contains only two underlying true peaks, repeated over three seeds.

### New expanded benchmark and exploratory hybrid (B4)

The expanded suite excludes DLinear: **NLinear is the only learned linear baseline**. Five classical models are DecisionTree, RandomForest, PCA-HistGB, PCA-SVR and KNN. PCA-HistGB and PCA-SVR explicitly compress training targets to eight PCA coordinates before fitting nonlinear regressors; they are not unrestricted independent-output implementations. They consume the same 104×7 standardized lag input. Training-only target PCA is fitted separately per L. Details and validation candidates are fixed in `protocol/config.json` before these new fits.

Neural baselines are NLinear, DNN, 1D CNN, GRU, TimesNet and Autoformer. All use Adam, MSE, 20 epochs, batch=16, lr=0.0005, validation-only checkpoint selection, seeds 42/43/44 and one frozen-winner test evaluation per cell. DNN has two width-64 hidden layers; CNN uses two width-16 convolutions and temporal pooling; GRU has width32; TimesNet uses width16, d_ff32, one block, top_k2, two convolution kernels; Autoformer uses width16/d_ff32, one encoder and decoder, two heads, moving-average25, label_len18. Autoformer uses its upstream normalization, while DNN/CNN/GRU use reversible window normalization. Calendar covariates are omitted because dates are synthetic. These are **compact, narrowly tuned exploratory implementations**, not fully optimized SOTA comparisons. Randomized tree ties/forests and neural initializations use seeds; deterministic KNN/SVR/HistGB repetitions are identical and do not create independent evidence.

We also execute **PeakBlend**, a feasibility experiment, not a novelty claim: w = sigmoid(b0 + b1 × (last observed ILITOTAL z − training q75) + b2 × last-four-week observed change). Forecast = w×NLinear + (1−w)×TimesNet. A fixed 18-combination gate grid is selected on validation all7 MSE plus ILITOTAL MSE above the **training q90** threshold. No test labels choose the gate; both experts remain frozen. Its inference requires both experts. The unchanged config is `protocol/hybrid_config.json`.

All these experiments are **EXPANDED_EXPLORATORY_966**, not Track C or paper reproduction runs. This historical test set was exposed before design. Validation-only selection within new scripts cannot turn an already exposed test into an untouched confirmatory test. Matching evaluation keys is necessary but does not prove historical baseline training fidelity or eliminate prior researcher adaptation.

## Results

### A2–A3: reproduction gap, existing experiment and realistic limits

The archived Track C figure {audit['track_c_mse']:.4f} and paper mean 1.4355 use different protocols and repetition counts. The {audit['descriptive_cross_protocol_gap_pct']:.2f}% separation is descriptive only. The correct five-percent band is [1.363725, 1.507275]; an absolute ±0.10 band is not equivalent to 5%.

The supplied earlier R1-C experiment already ran 24 fits (two candidates × four L × three seeds 1000–1002). We recomputed its table from `R1C_RESULTS_PER_CANDIDATE.csv`; no new GPU experiment is implied:

{t(rc)}

Within Track R, C0 mean is {audit['r1c_C0_mean']:.4f}, C1 mean {audit['r1c_C1_mean']:.4f}, difference C1−C0 = {audit['r1c_paired_delta']:.4f}, a 1.81% lower MSE and {audit['r1c_percent_gap_removed_within_R']:.2f}% of that Track R baseline-to-paper descriptive gap. It improves L36/L48/L60 and worsens L24. This **does not quantify any fraction of the Track C gap**. The paired seed-level 95% t interval is [{audit['r1c_paired_delta_95ci'][0]:.4f}, {audit['r1c_paired_delta_95ci'][1]:.4f}], p={audit['r1c_paired_t_p']:.4f}, n=3. It neither demonstrates superiority nor establishes non-inferiority. Treating all 12 correlated horizon cells as independent would overstate evidence.

Newly identified schedule alignment:

{t(timings.head(6))}

Candidate C2 matches the released end-of-previous-epoch update. `candidate_c2_train.py` is prepared in a separate path, with no change to evidence. **C2 is NOT RUN: per-L MSE, mean MSE, improvement and cost are unavailable.** A paper-method prefix-fusion reconstruction would be another explicit experimental arm, not a silent fix to Track C. The original corrected `r1b_model.py`, checkpoint/software fingerprints and matched GPU traces are required first.

An honest X%-seeds/Y%-architecture/Z%-unexplained causal decomposition is **not identifiable**: the factors are confounded, paper run-level outputs are absent and no controlled factorial experiment exists. The smallest supplied three-seed candidate mean is 1.8225 in **separate Track R**; it is an observed candidate, not the closest achievable optimum or a replacement for 1.8652. No available evidence establishes that a 5% tolerance is achievable, or proves it impossible. More seeds estimate randomness; they do not repair protocol differences. No percentage is assigned to hardware without a controlled rerun.

### B1: archived aggregate errors and valid ILITOTAL physical errors

{t(b1)}

Source: archived ranking CSV plus independent scoring of the 12 MIFlu prediction CSVs; `results/verified_miflu_cells.csv`. Four L receive equal weight, then three seeds receive equal weight; observations are not pooled across L with unequal counts.

### B2: archived scores by output-window length

{t(old)}

Normalized profile (MSE_L / own four-window mean):

{t(oldprof)}

MIFlu is lowest among the eight archived aggregates at every L. Its relative advantage over archived NLinear is not uniform. `results/B2_per_horizon_MSE_MAE.csv` retains both MSE and MAE per L. A falling profile for MIFlu must not be described as improved long-range forecast skill, because it mixes k and changes support. Actual-k data are in `miflu_actual_lead_means.csv` and Figure 4.

### B3: archived model × L peak results

The following means are conditional on matched k=1 peaks. PASS columns test **means only**, as requested; **event hit rate is the acceptance metric**, and a mean PASS is not evidence that all events pass. `n_true=9` means three underlying peaks repeated across three seeds. These are archive-derived numbers, not a verification of the unavailable CONSENSUS file.

{t(pks)}

MIFlu hits by L are 5/9, 4/9, 2/9 and 4/9, summing to 15/36. This pattern is nonmonotonic. The prompt's 31/36 is retained as an unresolved source assertion; in the supplied frozen tables **31/36 belongs to DLinear**. Do not silently substitute one for the other. The simplified 36/36 MIFlu count from START_HERE is not supported by these strict event tables.

Descriptive correlation across the eight archived models: Spearman rho between MSE and peak hit rate = {audit['mse_vs_peak_spearman_rho']:.4f}, p={audit['mse_vs_peak_spearman_p']:.4f}. Lower MSE tends to align with higher hit rate overall, but champions differ and the relationship is not one-to-one; with eight selected models and tied zeros this is not robust inferential evidence. MIFlu versus NLinear paired **seed-level** MSE difference is {audit['miflu_nlinear_paired_seed_mean_difference']:.4f}, exact two-sided sign-flip p={audit['miflu_nlinear_exact_signflip_p']:.4f}, n=3. Twelve correlated L×seed cells are not twelve independent datasets.

Shared-support actual-lead MIFlu diagnostic:

{t(epcommon)}

All terminal-lead mean PIE values exceed 25%, and terminal-lead hit rates reach zero at 48 and 60 weeks in this tiny diagnostic. Timing means alone look small partly because unmatched peaks are censored. This challenges extrapolating one-week diagnostics into long-horizon peak claims; it does not adjudicate the paper's separate few-shot figure or prove general inferiority.

### B4: newly executed expanded suite

New runs only; three seeds, equal four-window means. MIFlu's historical Track C score is kept in its separate table above. The lowest new-suite all7 MSE is {new_best:.4f} ({msebest}); this is a descriptive exploratory ranking, not a new authoritative champion.

{t(summary.reset_index())}

Per-L scores with both spaces. The two physical columns refer only to ILITOTAL; `mse_z_all7` is a different multivariate target:

{t(byL)}

Best/worst output-window lengths:

{t(wide.reset_index())}

Normalized per-L all7 profile (each model divided by its own mean):

{t(prof.reset_index())}

New-suite per-model × L peak diagnostics (k=1, legacy picker, matched-only means):

{t(ps)}

New-suite **actual terminal-lead** peak diagnostics, on the same target rows 832–942 at every L (two underlying peaks, repeated across three seeds; matched-only means):

{t(terminal_summary)}

The corresponding terminal-lead point errors are in `expanded_actual_terminal_scores.csv`; their k=L errors must not be confused with the mean over k=1…L in the main per-L table. Both peak tables use the frozen legacy picker for continuity and remain exploratory. New NLinear and PeakBlend each achieve zero terminal-lead hits at all four L on this common support, despite perfect k=1 hit rates. Their one-week success therefore provides no evidence of successful 24–60-week peak forecasting.

PeakBlend's full per-cell gate choices and validation objectives are retained, including unfavorable test outcomes. Its all7 mean MSE is {summary.loc['PeakBlend','mse_z_all7']:.4f}, **{hybrid_vs_nlinear:.2f}% higher than new NLinear** ({summary.loc['NLinear','mse_z_all7']:.4f}). Both achieve 36/36 hits in the k=1 legacy diagnostic, so this gate offers no gain over NLinear on that diagnostic and worsens aggregate MSE. This is a negative feasibility result, not a successful innovation claim. It is not evidence that gating improves MIFlu, because MIFlu is not one of its executable experts. A MIFlu+NLinear hybrid is a proposed future arm requiring matched validation predictions and the corrected original source.

Measured CPU costs (includes all candidates' training + validation; test prediction latency measured separately; checkpoint writing and environment setup excluded):

{t(c.reset_index())}

All new training used CPU, so measured GPU-hours are zero. Classical estimator NN parameter counts are NA; FLOPs are unmeasured, not zero. PeakBlend additional gate timing is in `results/hybrid/hybrid_cost.csv` and must be added to the two experts' training/inference costs for deployment. Historical MIFlu total cost (1.5083 GPU-hours across 12 fits) and parameter counts are provided by the handoff's `TRACK_C_COST_SUMMARY.csv` and `TRACK_C_MIFLU_RUN_MATRIX.csv`, not measured anew. CPU and A100 wall times are not directly interchangeable, so historical MIFlu is excluded from the CPU Pareto frontier. Timings come from concurrently running jobs on a shared host, not dedicated hardware trials.

### LLM and API execution status

{t(llm)}

These checkpoint families are requested comparators, not a claim to be the October-2026 SOTA frontier. No newly measured Qwen, DeepSeek, Llama, Mistral, GPT-4o or Claude performance is reported. The archived Qwen/TimeCMA/CALF methods are explicitly inspired simplifications; their scores cannot substitute for these missing paired experiments.

`run_llm_features.py` provides local-snapshot encoding-only and generation-augmented arms for compatible Transformers checkpoints. It uses identical observed-window summaries, the same frozen instruct model per pair, 16 train-fitted PCA feature dimensions and the same random-forest downstream regressor. Generation is deterministic, bounded to 96 tokens of structured analysis, cached and hashed; it is an operational generation augmentation, **not proof of internal reasoning**. Its incremental information and token budget must be matched against numerical-summary and extra-token controls. The prompt and code are included, with no API keys. Local weights and immutable revision metadata are required; it never silently downloads weights or uses a remote API. The DeepSeek custom/MoE families require their own reviewed backend; the generic runner is not asserted to support them. Generation-only commercial APIs cannot supply the identical hidden-state encoder arm, so they must remain a separate comparison.

## Discussion

### What makes MIFlu special?

The archived result supports strong contract-specific aggregate point forecasting, but it does not isolate the effect of text. Frozen token matrices are static across origins, their tokens vary, released fusion has a causal-access concern, and actual corrected Track C source is absent. A useful next experiment is a matched replay with original GPU/software/source fingerprints: full, zero-text of identical shape, semantically shuffled/irrelevant text, equal-shape random features, text removed with controlled RNG, random-initialized forecasting GPT-2 and no-pretraining controls. Reset dropout/random streams, use deterministic eval probes, retain exact tensors, measure gradients and forward perturbations on CPU and GPU. Prefix and cross-attention repairs should be named separate paper-method hypotheses. Until then the mechanism contradiction remains **UNRESOLVED**.

### Linear versus nonlinear forecasting

Archived NLinear excels at the legacy peak diagnostic, and the new NLinear is a competitive inexpensive reference. This justifies retaining it and excluding a redundant second learned linear baseline in the expanded suite. It does not establish that nonlinear modeling or language models are unnecessary: tail distribution shift, limited data and narrow hyperparameter budgets may explain this dataset's behavior. Classical tree-based regressors cannot extrapolate beyond training targets in the way a linear temporal map can; the large later ILITOTAL peaks make this a relevant hypothesis, not a proven causal explanation of their observed error. PCA target compression also limits the SVR/boosting arms and must be ablated before drawing family-level conclusions.

### When might LLM context add value?

Potential benefits are testable when context contains information unavailable in numeric lags, is timestamped before forecast issuance and is causally accessible to the model. Static variable descriptions may act as priors; that is different from dynamic policy or pathogen information. The present dataset alone cannot determine a sample-size threshold or a cross-location benefit. Few-shot subsets must be chronological training prefixes with validation retained, all prompt statistics refit on allowed training data, and fixed forecast targets.

### Scale, architecture and generation

A newer or larger text encoder does not automatically improve a forecasting task. Run paired encoding/generation arms with the same numerical backbone, feature dimensionality, fusion and training budget. Then vary model scale within a family, and fusion within a fixed model. Separate pretraining, architecture and representation effects with random-weight and non-LLM text controls. Full DeepSeek-V3 has 671B main-model parameters (37B activated per token according to its model card) and is not a single-small-GPU experiment; V2-Lite is a distinct smaller comparator, not equivalent evidence. Weight access, memory, energy and serving latency need measurement. No frontier improvement is inferred here.

### Peak versus point forecasting and the proposed innovation

The scientifically useful contribution is a **causally valid, peak-aware decision study**, not simply a longer list of LLMs. PeakBlend is a small executable feasibility probe. A stronger future model would combine a well-calibrated numerical point forecaster, an explicit amplitude/timing residual expert, and a gate driven by available text and observed numerical state. Train with a preregistered combination of multivariate point loss, target-tail loss and differentiable peak-timing loss; use validation only to choose trade-offs. Compare a constant ensemble, a numerical gate, a text gate and a sham-text gate at equal capacity. Demonstrate improved external-season peak forecasting without materially degrading point scores or calibration. Gating/ensembling itself is established; novelty and publication suitability must be established by causal evidence, robust evaluation and clinical relevance.

### Public-health deployment

No model is deployment-validated by these retrospective data. A numerical baseline is the sensible operational reference because it is inexpensive and inspectable, while MIFlu remains a point-forecast research comparator. Selection should depend on forecast-issuance lead, missed-peak cost, false alarms, calibrated intervals, coverage, latency, revision handling and real prospective data availability. ILITOTAL is a surveillance count of ILI visits, not unique laboratory-confirmed influenza cases or population incidence. Do not transfer US benchmark findings to Hong Kong without a separate jurisdiction-specific dataset and validation.

### Confirmatory protocol required before journal claims

1. Recover the missing corrected MIFlu source, original manifests/checkpoints, complete seven-model prediction arrays, `peak_criteria.json` and HPC guide/access. Resolve the peak-version conflict using provenance, not preference.
2. Commit and hash a single protocol before new untouched evaluation: data vintage, real epidemiological week mapping, variable order, allowed context timestamps, precise training budgets and candidate counts. Lock 10 repetitions for paper-oriented reproduction; use matched initialization and report seed-level results.
3. Keep Track C immutable. Add C2 source-matched schedule and explicitly separated prefix-fusion hypotheses. Select configurations on training/validation only; do not use proximity to 1.4355 as a tuning objective.
4. Add chronological rolling-origin folds and external seasons/jurisdictions, plus persistence and seasonal-naive references as non-fitted sanity controls. Do not duplicate NLinear with a second learned linear baseline. Report model-specific hyperparameter search budgets; a fixed 20 epochs alone does not equalize optimization quality.
5. Define fixed season or event windows using information available at issuance. Score the actual peak of each complete forecast trajectory, report lead to observed/predicted peak, timing/intensity errors, missed/false peaks and probabilistic calibration. Correct the minimum-distance implementation in a separately versioned protocol; retain the legacy picker only for historical reconciliation.
6. Use paired, block/season-aware resampling or forecast-loss tests that respect overlapping targets. Seeds measure optimization noise, not epidemiological diversity. Preregister multiplicity correction and primary endpoints; avoid treating repeated predictions of the same three peaks as independent epidemics.
7. Evaluate text/no-text, random/shuffled text, numeric summaries, token-budget controls and random-pretraining controls under identical feature/adapter budgets. Audit possible pretraining contamination: modern LLMs were trained after this historical test period, so absence of future values in the prompt alone does not establish prospective validity.
8. Measure dedicated-device end-to-end latency, feature-generation tokens, total/amortized training cost, parameters, FLOPs/energy where measurable, memory and prospective surveillance revision effects. Report failed and incomplete runs explicitly.

## Conclusion

The valid outcome remains **PARTIAL_REPRODUCTION**. The local audit reproduces the archived MIFlu aggregate, identifies invalid physical-unit conversion and misleading lead-time interpretation, exposes unresolved peak provenance and a scheduler shift, and executes an expanded numerical suite plus a transparent hybrid feasibility test. It does not establish that the text pathway helps or is useless, close the paper-level gap, or deliver an executed SOTA-LLM frontier. Those questions remain empirically open. The supplied code, prediction arrays, configuration hashes, tables, logs and figures make the completed work reviewable without claiming experiments that could not run.

## Figures

![Per-window MSE comparison](figures/per_window_MSE.png)

Figure 1. Newly executed model-window MSE; each bar averages actual leads 1…L and three seeds. This is not a terminal-lead chart.

![Peak timing and intensity diagnostic](figures/peak_scatter.png)

Figure 2. k=1 matched-peak PTE/PIE means; marker area reflects event hit rate. Censored timing failures and repeated seasons limit interpretation.

![CPU cost and error frontier](figures/cost_accuracy_pareto.png)

Figure 3. Mean CPU training/validation wall cost versus aggregate error. Historical GPU results and incomplete hybrid cost are excluded. Shared-host concurrency limits precise cost comparisons.

![Actual MIFlu lead profiles](figures/miflu_actual_leads.png)

Figure 4. Archived MIFlu actual forecast lead k within each L model. Complete values and valid origin counts are retained in CSV.

## Reproducibility and evidence map

| Claim / output | Original evidence or computation |
| --- | --- |
| Official data identity / split / scaler | `02_author_repo/code/dataset/illness/national_illness.csv`; `03_data/scaler_miflu_author966.json`; `results/scaler_verification.csv`, `window_counts.csv` |
| Archived eight-model aggregate and per-L scores | `08_paper_tables/TRACK_C_TEST_MSE_RANKING.csv`, `TRACK_C_PER_HORIZON_CHAMPIONS.csv`, `TRACK_C_PER_SEED_RANKINGS.csv` |
| Independent MIFlu MSE/MAE and physical target errors | 12 `04_benchmark/miflu/.../test_predictions_*.csv`; `code/audit.py`; `results/verified_miflu_cells.csv` |
| Archived peak per model/L | `04_benchmark/PTE_PIE_per_peak.csv`; `code/common.py:peak_summary`; `results/B3_legacy_k1_per_model_L.csv` |
| MIFlu true-lead shared-support peaks | Raw MIFlu predictions; `results/common_support_peak_events.csv`, `common_support_peak_summary.csv` |
| Prior scheduler experiment | `05_reproduction_audit/R1C_RESULTS_PER_CANDIDATE.csv`; `results/R1C_existing_24_fits.csv`, `R1C_per_L_means.csv` |
| New schedule shift | Author `main_ILI_lora.py` + `utils/tools.py`; R1C trainer; `code/scheduler_contract.py`, `results/scheduler_timeline.csv` |
| New classical/neural metrics | `results/expanded`, `timesnet`, `autoformer`: cell prediction NPZs, selected neural state, metric/selection/cost JSONs and logs |
| New hybrid | `protocol/hybrid_config.json`; `code/run_hybrid.py`; `results/hybrid`: gate candidates, predictions, costs |
| New all-model tables | `results/expanded_all_cells.csv`, `expanded_all_per_L.csv`, `expanded_all_peak_events.csv`, `expanded_all_peak_by_L.csv` |
| Figure inputs | CSVs named in `code/build_supplement.py`; figures also supplied as vector PDFs |
| Mechanism boundary controls | `code/mechanism_probe.py`; `results/mechanism_probe.json`; not a pretrained MIFlu replay |
| Preserved authoritative report | DOCX SHA256 `{audit['official_report_sha256']}`; MD mirror retained unchanged in the input archive |
| Missing / blocked evidence | `results/llm_execution_status.csv`; README continuation instructions |

All numerical table values derive from CSV/JSON files or the supplied paper's Table V. Display rounding is four decimals for MSE/MAE and two for percentages. NA means unavailable, not a zero-valued metric. `TABLES.md` repeats the numerical tables for convenient copying. The frozen input zip is included unchanged in the delivery bundle.
'''
    (base/'MIFlu_Research_Supplement_20261030.md').write_text(report,encoding='utf-8')
    print('Wrote supplement, TABLES.md, consolidated CSVs and four PNG/PDF figure pairs.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--handoff',required=True);p.add_argument('--output',required=True);main(p.parse_args())
