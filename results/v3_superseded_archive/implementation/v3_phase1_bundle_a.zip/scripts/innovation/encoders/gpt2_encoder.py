"""
gpt2_encoder.py — the existing frozen GPT-2 textual embedder, as a TextEncoder.
==============================================================================

Re-uses `scripts/textual_embedder.TextualInputEmbedder` (frozen GPT-2-small,
last hidden state, D=768). The prompt statistics come from `train_df` ONLY.

Availability requires the local gpt2 cache; nothing is downloaded.
"""

from __future__ import annotations

from innovation.backbones.gpt2_miflu_adapter import gpt2_cache_available
from innovation.interfaces import TextEncoder


class GPT2TextEncoder(TextEncoder):
    name = "gpt2"

    def __init__(self, device: str = "cpu"):
        self.device = device
        self.embedder = None
        self._htext: dict[int, "object"] = {}
        if not gpt2_cache_available():
            self.availability_note = (
                "UNAVAILABLE_LOCAL_DEPENDENCY: local gpt2 cache not found")

    def is_available(self) -> bool:
        try:
            import transformers  # noqa: F401
        except Exception:
            return False
        return gpt2_cache_available()

    def fit_on_train_only(self, train_df, horizon: int, seed: int) -> None:
        if not self.is_available():
            raise RuntimeError("UNAVAILABLE_LOCAL_DEPENDENCY: gpt2 unavailable")
        import torch

        from textual_embedder import TextualInputEmbedder, build_prompt

        if self.embedder is None:
            self.embedder = TextualInputEmbedder(device=self.device)
        prompt = build_prompt(train_df, T=104, L=horizon)
        with torch.no_grad():
            self._htext[int(horizon)] = self.embedder(prompt).detach().cpu()

    def encode(self, batch_size: int, device: str = "cpu", horizon: int | None = None):
        if self.embedder is None:
            return None
        h = int(horizon) if horizon is not None else next(iter(self._htext))
        t = self._htext[h].to(device)
        if t.shape[0] == 1 and batch_size > 1:
            t = t.expand(batch_size, -1, -1)
        return t

    def context_dim(self):
        return 768
